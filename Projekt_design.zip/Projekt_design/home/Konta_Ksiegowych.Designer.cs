﻿namespace home
{
    partial class Konta_Ksiegowych
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Konta_Ksiegowych));
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Del2_K = new Bunifu.Framework.UI.BunifuThinButton2();
            this.Usuntemp_2 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.Add_K = new Bunifu.Framework.UI.BunifuThinButton2();
            this.Refresh_K = new Bunifu.Framework.UI.BunifuThinButton2();
            this.SuspendLayout();
            // 
            // listView2
            // 
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader4,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader5,
            this.columnHeader6});
            this.listView2.FullRowSelect = true;
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(4, 4);
            this.listView2.Margin = new System.Windows.Forms.Padding(4);
            this.listView2.MultiSelect = false;
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(846, 450);
            this.listView2.TabIndex = 12;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID";
            this.columnHeader1.Width = 30;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Identyfikator firmowy";
            this.columnHeader4.Width = 200;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Imię";
            this.columnHeader2.Width = 120;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Nazwisko";
            this.columnHeader3.Width = 120;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Login";
            this.columnHeader5.Width = 120;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Hasło";
            this.columnHeader6.Width = 150;
            // 
            // Del2_K
            // 
            this.Del2_K.ActiveBorderThickness = 1;
            this.Del2_K.ActiveCornerRadius = 20;
            this.Del2_K.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.Del2_K.ActiveForecolor = System.Drawing.Color.White;
            this.Del2_K.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.Del2_K.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.Del2_K.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Del2_K.BackgroundImage")));
            this.Del2_K.ButtonText = "Usuń";
            this.Del2_K.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Del2_K.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Del2_K.ForeColor = System.Drawing.Color.SeaGreen;
            this.Del2_K.IdleBorderThickness = 1;
            this.Del2_K.IdleCornerRadius = 20;
            this.Del2_K.IdleFillColor = System.Drawing.Color.SandyBrown;
            this.Del2_K.IdleForecolor = System.Drawing.Color.White;
            this.Del2_K.IdleLineColor = System.Drawing.Color.White;
            this.Del2_K.Location = new System.Drawing.Point(653, 463);
            this.Del2_K.Margin = new System.Windows.Forms.Padding(5);
            this.Del2_K.Name = "Del2_K";
            this.Del2_K.Size = new System.Drawing.Size(175, 48);
            this.Del2_K.TabIndex = 19;
            this.Del2_K.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Usuntemp_2
            // 
            this.Usuntemp_2.ActiveBorderThickness = 1;
            this.Usuntemp_2.ActiveCornerRadius = 20;
            this.Usuntemp_2.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.Usuntemp_2.ActiveForecolor = System.Drawing.Color.White;
            this.Usuntemp_2.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.Usuntemp_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.Usuntemp_2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Usuntemp_2.BackgroundImage")));
            this.Usuntemp_2.ButtonText = "Tryb usuwania";
            this.Usuntemp_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Usuntemp_2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Usuntemp_2.ForeColor = System.Drawing.Color.SeaGreen;
            this.Usuntemp_2.IdleBorderThickness = 1;
            this.Usuntemp_2.IdleCornerRadius = 20;
            this.Usuntemp_2.IdleFillColor = System.Drawing.Color.SandyBrown;
            this.Usuntemp_2.IdleForecolor = System.Drawing.Color.White;
            this.Usuntemp_2.IdleLineColor = System.Drawing.Color.White;
            this.Usuntemp_2.Location = new System.Drawing.Point(444, 463);
            this.Usuntemp_2.Margin = new System.Windows.Forms.Padding(5);
            this.Usuntemp_2.Name = "Usuntemp_2";
            this.Usuntemp_2.Size = new System.Drawing.Size(175, 48);
            this.Usuntemp_2.TabIndex = 18;
            this.Usuntemp_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Add_K
            // 
            this.Add_K.ActiveBorderThickness = 1;
            this.Add_K.ActiveCornerRadius = 20;
            this.Add_K.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.Add_K.ActiveForecolor = System.Drawing.Color.White;
            this.Add_K.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.Add_K.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.Add_K.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Add_K.BackgroundImage")));
            this.Add_K.ButtonText = "Dodaj";
            this.Add_K.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add_K.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_K.ForeColor = System.Drawing.Color.SeaGreen;
            this.Add_K.IdleBorderThickness = 1;
            this.Add_K.IdleCornerRadius = 20;
            this.Add_K.IdleFillColor = System.Drawing.Color.SandyBrown;
            this.Add_K.IdleForecolor = System.Drawing.Color.White;
            this.Add_K.IdleLineColor = System.Drawing.Color.White;
            this.Add_K.Location = new System.Drawing.Point(228, 463);
            this.Add_K.Margin = new System.Windows.Forms.Padding(5);
            this.Add_K.Name = "Add_K";
            this.Add_K.Size = new System.Drawing.Size(175, 48);
            this.Add_K.TabIndex = 17;
            this.Add_K.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Refresh_K
            // 
            this.Refresh_K.ActiveBorderThickness = 1;
            this.Refresh_K.ActiveCornerRadius = 20;
            this.Refresh_K.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.Refresh_K.ActiveForecolor = System.Drawing.Color.White;
            this.Refresh_K.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.Refresh_K.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.Refresh_K.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Refresh_K.BackgroundImage")));
            this.Refresh_K.ButtonText = "Odśwież";
            this.Refresh_K.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Refresh_K.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Refresh_K.ForeColor = System.Drawing.Color.SeaGreen;
            this.Refresh_K.IdleBorderThickness = 1;
            this.Refresh_K.IdleCornerRadius = 20;
            this.Refresh_K.IdleFillColor = System.Drawing.Color.SandyBrown;
            this.Refresh_K.IdleForecolor = System.Drawing.Color.White;
            this.Refresh_K.IdleLineColor = System.Drawing.Color.White;
            this.Refresh_K.Location = new System.Drawing.Point(20, 463);
            this.Refresh_K.Margin = new System.Windows.Forms.Padding(5);
            this.Refresh_K.Name = "Refresh_K";
            this.Refresh_K.Size = new System.Drawing.Size(175, 48);
            this.Refresh_K.TabIndex = 16;
            this.Refresh_K.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Konta_Ksiegowych
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.Controls.Add(this.Del2_K);
            this.Controls.Add(this.Usuntemp_2);
            this.Controls.Add(this.Add_K);
            this.Controls.Add(this.Refresh_K);
            this.Controls.Add(this.listView2);
            this.Name = "Konta_Ksiegowych";
            this.Size = new System.Drawing.Size(854, 532);
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private Bunifu.Framework.UI.BunifuThinButton2 Del2_K;
        private Bunifu.Framework.UI.BunifuThinButton2 Usuntemp_2;
        private Bunifu.Framework.UI.BunifuThinButton2 Add_K;
        private Bunifu.Framework.UI.BunifuThinButton2 Refresh_K;
    }
}
