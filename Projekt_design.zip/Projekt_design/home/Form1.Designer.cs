﻿namespace home
{
    partial class Home
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.sidebar = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Log_Off = new Bunifu.Framework.UI.BunifuThinButton2();
            this.b4 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.b3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.b2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.b1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.logo = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.header = new System.Windows.Forms.Panel();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.container = new System.Windows.Forms.Panel();
            this.close = new Bunifu.UI.WinForms.BunifuImageButton();
            this.minimalize = new Bunifu.UI.WinForms.BunifuImageButton();
            this.draghome = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.sidebar.SuspendLayout();
            this.panel1.SuspendLayout();
            this.logo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.header.SuspendLayout();
            this.SuspendLayout();
            // 
            // sidebar
            // 
            this.sidebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(104)))), ((int)(((byte)(114)))));
            this.sidebar.Controls.Add(this.panel1);
            this.sidebar.Controls.Add(this.b4);
            this.sidebar.Controls.Add(this.b3);
            this.sidebar.Controls.Add(this.b2);
            this.sidebar.Controls.Add(this.b1);
            this.sidebar.Controls.Add(this.logo);
            this.sidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebar.Location = new System.Drawing.Point(0, 0);
            this.sidebar.Name = "sidebar";
            this.sidebar.Size = new System.Drawing.Size(272, 659);
            this.sidebar.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Log_Off);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 559);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(272, 100);
            this.panel1.TabIndex = 6;
            // 
            // Log_Off
            // 
            this.Log_Off.ActiveBorderThickness = 1;
            this.Log_Off.ActiveCornerRadius = 20;
            this.Log_Off.ActiveFillColor = System.Drawing.Color.SandyBrown;
            this.Log_Off.ActiveForecolor = System.Drawing.Color.Black;
            this.Log_Off.ActiveLineColor = System.Drawing.Color.White;
            this.Log_Off.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(104)))), ((int)(((byte)(114)))));
            this.Log_Off.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Log_Off.BackgroundImage")));
            this.Log_Off.ButtonText = "Wyloguj";
            this.Log_Off.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Log_Off.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Log_Off.ForeColor = System.Drawing.Color.SandyBrown;
            this.Log_Off.IdleBorderThickness = 1;
            this.Log_Off.IdleCornerRadius = 20;
            this.Log_Off.IdleFillColor = System.Drawing.Color.White;
            this.Log_Off.IdleForecolor = System.Drawing.Color.SandyBrown;
            this.Log_Off.IdleLineColor = System.Drawing.Color.SandyBrown;
            this.Log_Off.Location = new System.Drawing.Point(43, 24);
            this.Log_Off.Margin = new System.Windows.Forms.Padding(5);
            this.Log_Off.Name = "Log_Off";
            this.Log_Off.Size = new System.Drawing.Size(181, 49);
            this.Log_Off.TabIndex = 0;
            this.Log_Off.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // b4
            // 
            this.b4.Active = false;
            this.b4.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.b4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(104)))), ((int)(((byte)(114)))));
            this.b4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.b4.BorderRadius = 0;
            this.b4.ButtonText = "   Konta Ksiegowych";
            this.b4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.b4.DisabledColor = System.Drawing.Color.Gray;
            this.b4.Dock = System.Windows.Forms.DockStyle.Top;
            this.b4.ForeColor = System.Drawing.Color.White;
            this.b4.Iconcolor = System.Drawing.Color.Transparent;
            this.b4.Iconimage = null;
            this.b4.Iconimage_right = null;
            this.b4.Iconimage_right_Selected = null;
            this.b4.Iconimage_Selected = null;
            this.b4.IconMarginLeft = 0;
            this.b4.IconMarginRight = 0;
            this.b4.IconRightVisible = true;
            this.b4.IconRightZoom = 0D;
            this.b4.IconVisible = true;
            this.b4.IconZoom = 90D;
            this.b4.IsTab = true;
            this.b4.Location = new System.Drawing.Point(0, 306);
            this.b4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.b4.Name = "b4";
            this.b4.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(104)))), ((int)(((byte)(114)))));
            this.b4.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.b4.OnHoverTextColor = System.Drawing.Color.SandyBrown;
            this.b4.selected = false;
            this.b4.Size = new System.Drawing.Size(272, 74);
            this.b4.TabIndex = 5;
            this.b4.Text = "   Konta Ksiegowych";
            this.b4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.b4.Textcolor = System.Drawing.Color.White;
            this.b4.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b4.Click += new System.EventHandler(this.b4_Click);
            // 
            // b3
            // 
            this.b3.Active = false;
            this.b3.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.b3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(104)))), ((int)(((byte)(114)))));
            this.b3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.b3.BorderRadius = 0;
            this.b3.ButtonText = "   Dane";
            this.b3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.b3.DisabledColor = System.Drawing.Color.Gray;
            this.b3.Dock = System.Windows.Forms.DockStyle.Top;
            this.b3.ForeColor = System.Drawing.Color.White;
            this.b3.Iconcolor = System.Drawing.Color.Transparent;
            this.b3.Iconimage = null;
            this.b3.Iconimage_right = null;
            this.b3.Iconimage_right_Selected = null;
            this.b3.Iconimage_Selected = null;
            this.b3.IconMarginLeft = 0;
            this.b3.IconMarginRight = 0;
            this.b3.IconRightVisible = true;
            this.b3.IconRightZoom = 0D;
            this.b3.IconVisible = true;
            this.b3.IconZoom = 90D;
            this.b3.IsTab = true;
            this.b3.Location = new System.Drawing.Point(0, 232);
            this.b3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.b3.Name = "b3";
            this.b3.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(104)))), ((int)(((byte)(114)))));
            this.b3.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.b3.OnHoverTextColor = System.Drawing.Color.SandyBrown;
            this.b3.selected = false;
            this.b3.Size = new System.Drawing.Size(272, 74);
            this.b3.TabIndex = 4;
            this.b3.Text = "   Dane";
            this.b3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.b3.Textcolor = System.Drawing.Color.White;
            this.b3.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b3.Click += new System.EventHandler(this.b3_Click);
            // 
            // b2
            // 
            this.b2.Active = false;
            this.b2.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.b2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(104)))), ((int)(((byte)(114)))));
            this.b2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.b2.BorderRadius = 0;
            this.b2.ButtonText = "   Widok bazodanowy";
            this.b2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.b2.DisabledColor = System.Drawing.Color.Gray;
            this.b2.Dock = System.Windows.Forms.DockStyle.Top;
            this.b2.ForeColor = System.Drawing.Color.White;
            this.b2.Iconcolor = System.Drawing.Color.Transparent;
            this.b2.Iconimage = null;
            this.b2.Iconimage_right = null;
            this.b2.Iconimage_right_Selected = null;
            this.b2.Iconimage_Selected = null;
            this.b2.IconMarginLeft = 0;
            this.b2.IconMarginRight = 0;
            this.b2.IconRightVisible = true;
            this.b2.IconRightZoom = 0D;
            this.b2.IconVisible = true;
            this.b2.IconZoom = 90D;
            this.b2.IsTab = true;
            this.b2.Location = new System.Drawing.Point(0, 158);
            this.b2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.b2.Name = "b2";
            this.b2.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(104)))), ((int)(((byte)(114)))));
            this.b2.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.b2.OnHoverTextColor = System.Drawing.Color.SandyBrown;
            this.b2.selected = false;
            this.b2.Size = new System.Drawing.Size(272, 74);
            this.b2.TabIndex = 3;
            this.b2.Text = "   Widok bazodanowy";
            this.b2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.b2.Textcolor = System.Drawing.Color.White;
            this.b2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b2.Click += new System.EventHandler(this.b2_Click);
            // 
            // b1
            // 
            this.b1.Active = true;
            this.b1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.b1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.b1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.b1.BorderRadius = 0;
            this.b1.ButtonText = "   Połączenie z bazą danych";
            this.b1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.b1.DisabledColor = System.Drawing.Color.Gray;
            this.b1.Dock = System.Windows.Forms.DockStyle.Top;
            this.b1.ForeColor = System.Drawing.Color.White;
            this.b1.Iconcolor = System.Drawing.Color.Transparent;
            this.b1.Iconimage = null;
            this.b1.Iconimage_right = null;
            this.b1.Iconimage_right_Selected = null;
            this.b1.Iconimage_Selected = null;
            this.b1.IconMarginLeft = 0;
            this.b1.IconMarginRight = 0;
            this.b1.IconRightVisible = true;
            this.b1.IconRightZoom = 0D;
            this.b1.IconVisible = true;
            this.b1.IconZoom = 90D;
            this.b1.IsTab = true;
            this.b1.Location = new System.Drawing.Point(0, 84);
            this.b1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.b1.Name = "b1";
            this.b1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(104)))), ((int)(((byte)(114)))));
            this.b1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(83)))), ((int)(((byte)(94)))), ((int)(((byte)(104)))));
            this.b1.OnHoverTextColor = System.Drawing.Color.SandyBrown;
            this.b1.selected = true;
            this.b1.Size = new System.Drawing.Size(272, 74);
            this.b1.TabIndex = 2;
            this.b1.Text = "   Połączenie z bazą danych";
            this.b1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.b1.Textcolor = System.Drawing.Color.White;
            this.b1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.b1.Click += new System.EventHandler(this.b1_Click);
            // 
            // logo
            // 
            this.logo.BackColor = System.Drawing.Color.SandyBrown;
            this.logo.Controls.Add(this.pictureBox1);
            this.logo.Controls.Add(this.label1);
            this.logo.Dock = System.Windows.Forms.DockStyle.Top;
            this.logo.Location = new System.Drawing.Point(0, 0);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(272, 84);
            this.logo.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(65, 48);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Book Antiqua", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(74, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 34);
            this.label1.TabIndex = 2;
            this.label1.Text = "Księgowy IO";
            // 
            // header
            // 
            this.header.BackColor = System.Drawing.Color.White;
            this.header.Controls.Add(this.minimalize);
            this.header.Controls.Add(this.close);
            this.header.Dock = System.Windows.Forms.DockStyle.Top;
            this.header.Location = new System.Drawing.Point(272, 0);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(896, 84);
            this.header.TabIndex = 1;
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 15;
            this.bunifuElipse1.TargetControl = this;
            // 
            // container
            // 
            this.container.Dock = System.Windows.Forms.DockStyle.Fill;
            this.container.Location = new System.Drawing.Point(272, 84);
            this.container.Name = "container";
            this.container.Size = new System.Drawing.Size(896, 575);
            this.container.TabIndex = 2;
            // 
            // close
            // 
            this.close.ActiveImage = null;
            this.close.AllowAnimations = true;
            this.close.AllowZooming = true;
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.ErrorImage = ((System.Drawing.Image)(resources.GetObject("close.ErrorImage")));
            this.close.FadeWhenInactive = false;
            this.close.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.close.Image = ((System.Drawing.Image)(resources.GetObject("close.Image")));
            this.close.ImageActive = null;
            this.close.ImageLocation = null;
            this.close.ImageMargin = 0;
            this.close.ImageSize = new System.Drawing.Size(37, 34);
            this.close.ImageZoomSize = new System.Drawing.Size(37, 34);
            this.close.InitialImage = ((System.Drawing.Image)(resources.GetObject("close.InitialImage")));
            this.close.Location = new System.Drawing.Point(835, 26);
            this.close.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.close.Name = "close";
            this.close.Rotation = 0;
            this.close.ShowActiveImage = true;
            this.close.ShowCursorChanges = true;
            this.close.ShowImageBorders = false;
            this.close.ShowSizeMarkers = false;
            this.close.Size = new System.Drawing.Size(37, 34);
            this.close.TabIndex = 7;
            this.close.ToolTipText = "";
            this.close.WaitOnLoad = false;
            this.close.Zoom = 0;
            this.close.ZoomSpeed = 10;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // minimalize
            // 
            this.minimalize.ActiveImage = null;
            this.minimalize.AllowAnimations = true;
            this.minimalize.AllowZooming = true;
            this.minimalize.BackColor = System.Drawing.Color.Transparent;
            this.minimalize.ErrorImage = ((System.Drawing.Image)(resources.GetObject("minimalize.ErrorImage")));
            this.minimalize.FadeWhenInactive = false;
            this.minimalize.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.minimalize.Image = ((System.Drawing.Image)(resources.GetObject("minimalize.Image")));
            this.minimalize.ImageActive = null;
            this.minimalize.ImageLocation = null;
            this.minimalize.ImageMargin = 0;
            this.minimalize.ImageSize = new System.Drawing.Size(37, 34);
            this.minimalize.ImageZoomSize = new System.Drawing.Size(37, 34);
            this.minimalize.InitialImage = ((System.Drawing.Image)(resources.GetObject("minimalize.InitialImage")));
            this.minimalize.Location = new System.Drawing.Point(790, 26);
            this.minimalize.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.minimalize.Name = "minimalize";
            this.minimalize.Rotation = 0;
            this.minimalize.ShowActiveImage = true;
            this.minimalize.ShowCursorChanges = true;
            this.minimalize.ShowImageBorders = false;
            this.minimalize.ShowSizeMarkers = false;
            this.minimalize.Size = new System.Drawing.Size(37, 34);
            this.minimalize.TabIndex = 8;
            this.minimalize.ToolTipText = "";
            this.minimalize.WaitOnLoad = false;
            this.minimalize.Zoom = 0;
            this.minimalize.ZoomSpeed = 10;
            this.minimalize.Click += new System.EventHandler(this.minimalize_Click);
            // 
            // draghome
            // 
            this.draghome.Fixed = true;
            this.draghome.Horizontal = true;
            this.draghome.TargetControl = this.header;
            this.draghome.Vertical = true;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.ClientSize = new System.Drawing.Size(1168, 659);
            this.Controls.Add(this.container);
            this.Controls.Add(this.header);
            this.Controls.Add(this.sidebar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Home";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Home_Load);
            this.sidebar.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.logo.ResumeLayout(false);
            this.logo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.header.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sidebar;
        private System.Windows.Forms.Panel logo;
        private System.Windows.Forms.Panel header;
        private Bunifu.Framework.UI.BunifuFlatButton b4;
        private Bunifu.Framework.UI.BunifuFlatButton b3;
        private Bunifu.Framework.UI.BunifuFlatButton b2;
        private Bunifu.Framework.UI.BunifuFlatButton b1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuThinButton2 Log_Off;
        private System.Windows.Forms.Panel container;
        private Bunifu.UI.WinForms.BunifuImageButton minimalize;
        private Bunifu.UI.WinForms.BunifuImageButton close;
        private Bunifu.Framework.UI.BunifuDragControl draghome;
    }
}

