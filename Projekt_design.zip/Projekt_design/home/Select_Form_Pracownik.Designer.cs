﻿namespace home
{
    partial class Select_Form_Pracownik
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Select_Form_Pracownik));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.header = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.listView5 = new System.Windows.Forms.ListView();
            this.ch0 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ch1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ch2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listView6 = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.osoba = new System.Windows.Forms.Panel();
            this.netto = new System.Windows.Forms.Label();
            this.zatrud = new System.Windows.Forms.Label();
            this.czyst = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pesel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.stanowisko = new System.Windows.Forms.Label();
            this.plec = new System.Windows.Forms.Label();
            this.nazwisko = new System.Windows.Forms.Label();
            this.imie = new System.Windows.Forms.Label();
            this.id = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.bunifuElipse2 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuDragControl6 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.button1 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.minimalize = new Bunifu.UI.WinForms.BunifuImageButton();
            this.close = new Bunifu.UI.WinForms.BunifuImageButton();
            this.header.SuspendLayout();
            this.osoba.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // header
            // 
            this.header.BackColor = System.Drawing.Color.White;
            this.header.Controls.Add(this.minimalize);
            this.header.Controls.Add(this.close);
            this.header.Controls.Add(this.label1);
            this.header.Dock = System.Windows.Forms.DockStyle.Top;
            this.header.Location = new System.Drawing.Point(0, 0);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(1190, 72);
            this.header.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Book Antiqua", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(77, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 34);
            this.label1.TabIndex = 15;
            this.label1.Text = "Księgowy IO";
            // 
            // listView5
            // 
            this.listView5.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ch0,
            this.ch1,
            this.ch2});
            this.listView5.Location = new System.Drawing.Point(296, 131);
            this.listView5.Margin = new System.Windows.Forms.Padding(4);
            this.listView5.Name = "listView5";
            this.listView5.Size = new System.Drawing.Size(845, 127);
            this.listView5.TabIndex = 18;
            this.listView5.UseCompatibleStateImageBehavior = false;
            this.listView5.View = System.Windows.Forms.View.Details;
            // 
            // ch0
            // 
            this.ch0.Text = "Typ zwolnienia";
            this.ch0.Width = 122;
            // 
            // ch1
            // 
            this.ch1.Text = "Zwolnienie od";
            this.ch1.Width = 250;
            // 
            // ch2
            // 
            this.ch2.Text = "Zwolnienie do";
            this.ch2.Width = 255;
            // 
            // listView6
            // 
            this.listView6.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader3,
            this.columnHeader2,
            this.columnHeader1,
            this.columnHeader6,
            this.columnHeader5});
            this.listView6.Location = new System.Drawing.Point(296, 331);
            this.listView6.Margin = new System.Windows.Forms.Padding(4);
            this.listView6.Name = "listView6";
            this.listView6.Size = new System.Drawing.Size(845, 157);
            this.listView6.TabIndex = 22;
            this.listView6.UseCompatibleStateImageBehavior = false;
            this.listView6.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Miesiąc";
            this.columnHeader4.Width = 100;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Kwota netto";
            this.columnHeader3.Width = 120;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Kwota brutto";
            this.columnHeader2.Width = 120;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Kwota brutto brutto";
            this.columnHeader1.Width = 120;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Składki suma";
            this.columnHeader6.Width = 120;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Rok";
            this.columnHeader5.Width = 50;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = null;
            this.bunifuLabel1.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel1.Location = new System.Drawing.Point(653, 90);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(138, 23);
            this.bunifuLabel1.TabIndex = 23;
            this.bunifuLabel1.Text = "Historia Zwolnien";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = null;
            this.bunifuLabel2.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel2.Location = new System.Drawing.Point(572, 285);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(309, 23);
            this.bunifuLabel2.TabIndex = 24;
            this.bunifuLabel2.Text = "Historia pensji na podstawie zwolnien";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // osoba
            // 
            this.osoba.BackColor = System.Drawing.Color.White;
            this.osoba.Controls.Add(this.netto);
            this.osoba.Controls.Add(this.zatrud);
            this.osoba.Controls.Add(this.czyst);
            this.osoba.Controls.Add(this.label9);
            this.osoba.Controls.Add(this.label8);
            this.osoba.Controls.Add(this.label6);
            this.osoba.Controls.Add(this.pesel);
            this.osoba.Controls.Add(this.label7);
            this.osoba.Controls.Add(this.stanowisko);
            this.osoba.Controls.Add(this.plec);
            this.osoba.Controls.Add(this.nazwisko);
            this.osoba.Controls.Add(this.imie);
            this.osoba.Controls.Add(this.id);
            this.osoba.Controls.Add(this.label5);
            this.osoba.Controls.Add(this.label4);
            this.osoba.Controls.Add(this.label3);
            this.osoba.Controls.Add(this.label2);
            this.osoba.Controls.Add(this.label10);
            this.osoba.Location = new System.Drawing.Point(12, 131);
            this.osoba.Name = "osoba";
            this.osoba.Size = new System.Drawing.Size(260, 288);
            this.osoba.TabIndex = 25;
            // 
            // netto
            // 
            this.netto.AutoSize = true;
            this.netto.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.netto.Location = new System.Drawing.Point(109, 253);
            this.netto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.netto.Name = "netto";
            this.netto.Size = new System.Drawing.Size(0, 19);
            this.netto.TabIndex = 60;
            // 
            // zatrud
            // 
            this.zatrud.AutoSize = true;
            this.zatrud.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.zatrud.Location = new System.Drawing.Point(109, 220);
            this.zatrud.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.zatrud.Name = "zatrud";
            this.zatrud.Size = new System.Drawing.Size(0, 19);
            this.zatrud.TabIndex = 59;
            // 
            // czyst
            // 
            this.czyst.AutoSize = true;
            this.czyst.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.czyst.Location = new System.Drawing.Point(109, 186);
            this.czyst.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.czyst.Name = "czyst";
            this.czyst.Size = new System.Drawing.Size(0, 19);
            this.czyst.TabIndex = 58;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label9.Location = new System.Drawing.Point(13, 253);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 19);
            this.label9.TabIndex = 57;
            this.label9.Text = "Pensja brutto";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label8.Location = new System.Drawing.Point(13, 220);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 19);
            this.label8.TabIndex = 56;
            this.label8.Text = "Zatrudnienie";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label6.Location = new System.Drawing.Point(13, 186);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 19);
            this.label6.TabIndex = 55;
            this.label6.Text = "Czy Student?";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pesel
            // 
            this.pesel.AutoSize = true;
            this.pesel.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pesel.Location = new System.Drawing.Point(108, 95);
            this.pesel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pesel.Name = "pesel";
            this.pesel.Size = new System.Drawing.Size(0, 19);
            this.pesel.TabIndex = 54;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label7.Location = new System.Drawing.Point(49, 95);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 19);
            this.label7.TabIndex = 53;
            this.label7.Text = "PESEL";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // stanowisko
            // 
            this.stanowisko.AutoSize = true;
            this.stanowisko.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.stanowisko.Location = new System.Drawing.Point(108, 152);
            this.stanowisko.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.stanowisko.Name = "stanowisko";
            this.stanowisko.Size = new System.Drawing.Size(0, 19);
            this.stanowisko.TabIndex = 52;
            // 
            // plec
            // 
            this.plec.AutoSize = true;
            this.plec.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.plec.Location = new System.Drawing.Point(108, 123);
            this.plec.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.plec.Name = "plec";
            this.plec.Size = new System.Drawing.Size(0, 19);
            this.plec.TabIndex = 51;
            // 
            // nazwisko
            // 
            this.nazwisko.AutoSize = true;
            this.nazwisko.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nazwisko.Location = new System.Drawing.Point(108, 71);
            this.nazwisko.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nazwisko.Name = "nazwisko";
            this.nazwisko.Size = new System.Drawing.Size(0, 19);
            this.nazwisko.TabIndex = 50;
            // 
            // imie
            // 
            this.imie.AutoSize = true;
            this.imie.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.imie.Location = new System.Drawing.Point(108, 40);
            this.imie.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.imie.Name = "imie";
            this.imie.Size = new System.Drawing.Size(0, 19);
            this.imie.TabIndex = 49;
            // 
            // id
            // 
            this.id.AutoSize = true;
            this.id.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.id.Location = new System.Drawing.Point(108, 13);
            this.id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(0, 19);
            this.id.TabIndex = 48;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label5.Location = new System.Drawing.Point(73, 13);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(22, 19);
            this.label5.TabIndex = 47;
            this.label5.Text = "ID";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label4.Location = new System.Drawing.Point(14, 152);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 19);
            this.label4.TabIndex = 46;
            this.label4.Text = "Stanowisko";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label3.Location = new System.Drawing.Point(58, 123);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 19);
            this.label3.TabIndex = 45;
            this.label3.Text = "Płeć";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label2.Location = new System.Drawing.Point(26, 71);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 19);
            this.label2.TabIndex = 44;
            this.label2.Text = "Nazwisko";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label10.Location = new System.Drawing.Point(62, 40);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 19);
            this.label10.TabIndex = 43;
            this.label10.Text = "Imię";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // bunifuElipse2
            // 
            this.bunifuElipse2.ElipseRadius = 5;
            this.bunifuElipse2.TargetControl = this.osoba;
            // 
            // bunifuDragControl6
            // 
            this.bunifuDragControl6.Fixed = true;
            this.bunifuDragControl6.Horizontal = true;
            this.bunifuDragControl6.TargetControl = this.header;
            this.bunifuDragControl6.Vertical = true;
            // 
            // button1
            // 
            this.button1.ActiveBorderThickness = 1;
            this.button1.ActiveCornerRadius = 20;
            this.button1.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.button1.ActiveForecolor = System.Drawing.Color.White;
            this.button1.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.ButtonText = "Generuj szczegółowy raport o wynagrodzeniu";
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.SeaGreen;
            this.button1.IdleBorderThickness = 1;
            this.button1.IdleCornerRadius = 20;
            this.button1.IdleFillColor = System.Drawing.Color.SandyBrown;
            this.button1.IdleForecolor = System.Drawing.Color.White;
            this.button1.IdleLineColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(471, 514);
            this.button1.Margin = new System.Windows.Forms.Padding(5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(500, 55);
            this.button1.TabIndex = 26;
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // minimalize
            // 
            this.minimalize.ActiveImage = null;
            this.minimalize.AllowAnimations = true;
            this.minimalize.AllowZooming = true;
            this.minimalize.BackColor = System.Drawing.Color.Transparent;
            this.minimalize.ErrorImage = ((System.Drawing.Image)(resources.GetObject("minimalize.ErrorImage")));
            this.minimalize.FadeWhenInactive = false;
            this.minimalize.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.minimalize.Image = ((System.Drawing.Image)(resources.GetObject("minimalize.Image")));
            this.minimalize.ImageActive = null;
            this.minimalize.ImageLocation = null;
            this.minimalize.ImageMargin = 0;
            this.minimalize.ImageSize = new System.Drawing.Size(37, 34);
            this.minimalize.ImageZoomSize = new System.Drawing.Size(37, 34);
            this.minimalize.InitialImage = ((System.Drawing.Image)(resources.GetObject("minimalize.InitialImage")));
            this.minimalize.Location = new System.Drawing.Point(1075, 19);
            this.minimalize.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.minimalize.Name = "minimalize";
            this.minimalize.Rotation = 0;
            this.minimalize.ShowActiveImage = true;
            this.minimalize.ShowCursorChanges = true;
            this.minimalize.ShowImageBorders = false;
            this.minimalize.ShowSizeMarkers = false;
            this.minimalize.Size = new System.Drawing.Size(37, 34);
            this.minimalize.TabIndex = 17;
            this.minimalize.ToolTipText = "";
            this.minimalize.WaitOnLoad = false;
            this.minimalize.Zoom = 0;
            this.minimalize.ZoomSpeed = 10;
            this.minimalize.Click += new System.EventHandler(this.minimalize_Click);
            // 
            // close
            // 
            this.close.ActiveImage = null;
            this.close.AllowAnimations = true;
            this.close.AllowZooming = true;
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.ErrorImage = ((System.Drawing.Image)(resources.GetObject("close.ErrorImage")));
            this.close.FadeWhenInactive = false;
            this.close.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.close.Image = ((System.Drawing.Image)(resources.GetObject("close.Image")));
            this.close.ImageActive = null;
            this.close.ImageLocation = null;
            this.close.ImageMargin = 0;
            this.close.ImageSize = new System.Drawing.Size(37, 34);
            this.close.ImageZoomSize = new System.Drawing.Size(37, 34);
            this.close.InitialImage = ((System.Drawing.Image)(resources.GetObject("close.InitialImage")));
            this.close.Location = new System.Drawing.Point(1120, 19);
            this.close.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.close.Name = "close";
            this.close.Rotation = 0;
            this.close.ShowActiveImage = true;
            this.close.ShowCursorChanges = true;
            this.close.ShowImageBorders = false;
            this.close.ShowSizeMarkers = false;
            this.close.Size = new System.Drawing.Size(37, 34);
            this.close.TabIndex = 16;
            this.close.ToolTipText = "";
            this.close.WaitOnLoad = false;
            this.close.Zoom = 0;
            this.close.ZoomSpeed = 10;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // Select_Form_Pracownik
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.ClientSize = new System.Drawing.Size(1190, 612);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.osoba);
            this.Controls.Add(this.bunifuLabel2);
            this.Controls.Add(this.bunifuLabel1);
            this.Controls.Add(this.listView6);
            this.Controls.Add(this.listView5);
            this.Controls.Add(this.header);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Select_Form_Pracownik";
            this.Text = "Select_Form_Pracownik";
            this.header.ResumeLayout(false);
            this.header.PerformLayout();
            this.osoba.ResumeLayout(false);
            this.osoba.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel header;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel osoba;
        public System.Windows.Forms.Label netto;
        public System.Windows.Forms.Label zatrud;
        public System.Windows.Forms.Label czyst;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label pesel;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label stanowisko;
        public System.Windows.Forms.Label plec;
        public System.Windows.Forms.Label nazwisko;
        public System.Windows.Forms.Label imie;
        public System.Windows.Forms.Label id;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        public System.Windows.Forms.ListView listView6;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        public System.Windows.Forms.ListView listView5;
        private System.Windows.Forms.ColumnHeader ch0;
        private System.Windows.Forms.ColumnHeader ch1;
        private System.Windows.Forms.ColumnHeader ch2;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse2;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl6;
        private Bunifu.Framework.UI.BunifuThinButton2 button1;
        private Bunifu.UI.WinForms.BunifuImageButton minimalize;
        private Bunifu.UI.WinForms.BunifuImageButton close;
    }
}