﻿namespace home
{
    partial class Logowanie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Logowanie));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.glowa = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Login_TxtBox = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.Haslo_TxtBox = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.Check_Butt = new Bunifu.Framework.UI.BunifuThinButton2();
            this.minimalize = new Bunifu.UI.WinForms.BunifuImageButton();
            this.close = new Bunifu.UI.WinForms.BunifuImageButton();
            this.glowa.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // glowa
            // 
            this.glowa.BackColor = System.Drawing.Color.White;
            this.glowa.Controls.Add(this.minimalize);
            this.glowa.Controls.Add(this.close);
            this.glowa.Controls.Add(this.label1);
            this.glowa.Dock = System.Windows.Forms.DockStyle.Top;
            this.glowa.Location = new System.Drawing.Point(0, 0);
            this.glowa.Name = "glowa";
            this.glowa.Size = new System.Drawing.Size(548, 95);
            this.glowa.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Book Antiqua", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(52, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 34);
            this.label1.TabIndex = 3;
            this.label1.Text = "Księgowy IO";
            // 
            // Login_TxtBox
            // 
            this.Login_TxtBox.AcceptsReturn = false;
            this.Login_TxtBox.AcceptsTab = false;
            this.Login_TxtBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Login_TxtBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Login_TxtBox.BackColor = System.Drawing.Color.Transparent;
            this.Login_TxtBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Login_TxtBox.BackgroundImage")));
            this.Login_TxtBox.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.Login_TxtBox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Login_TxtBox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.Login_TxtBox.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.Login_TxtBox.BorderRadius = 1;
            this.Login_TxtBox.BorderThickness = 2;
            this.Login_TxtBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Login_TxtBox.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Login_TxtBox.DefaultText = "";
            this.Login_TxtBox.FillColor = System.Drawing.Color.White;
            this.Login_TxtBox.HideSelection = true;
            this.Login_TxtBox.IconLeft = null;
            this.Login_TxtBox.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.Login_TxtBox.IconPadding = 10;
            this.Login_TxtBox.IconRight = null;
            this.Login_TxtBox.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.Login_TxtBox.Location = new System.Drawing.Point(181, 224);
            this.Login_TxtBox.MaxLength = 32767;
            this.Login_TxtBox.MinimumSize = new System.Drawing.Size(100, 35);
            this.Login_TxtBox.Modified = false;
            this.Login_TxtBox.Name = "Login_TxtBox";
            this.Login_TxtBox.PasswordChar = '\0';
            this.Login_TxtBox.ReadOnly = false;
            this.Login_TxtBox.SelectedText = "";
            this.Login_TxtBox.SelectionLength = 0;
            this.Login_TxtBox.SelectionStart = 0;
            this.Login_TxtBox.ShortcutsEnabled = true;
            this.Login_TxtBox.Size = new System.Drawing.Size(200, 35);
            this.Login_TxtBox.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.Login_TxtBox.TabIndex = 1;
            this.Login_TxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Login_TxtBox.TextMarginLeft = 5;
            this.Login_TxtBox.TextPlaceholder = "";
            this.Login_TxtBox.UseSystemPasswordChar = false;
            // 
            // Haslo_TxtBox
            // 
            this.Haslo_TxtBox.AcceptsReturn = false;
            this.Haslo_TxtBox.AcceptsTab = false;
            this.Haslo_TxtBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Haslo_TxtBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Haslo_TxtBox.BackColor = System.Drawing.Color.Transparent;
            this.Haslo_TxtBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Haslo_TxtBox.BackgroundImage")));
            this.Haslo_TxtBox.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.Haslo_TxtBox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Haslo_TxtBox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.Haslo_TxtBox.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.Haslo_TxtBox.BorderRadius = 1;
            this.Haslo_TxtBox.BorderThickness = 2;
            this.Haslo_TxtBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Haslo_TxtBox.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Haslo_TxtBox.DefaultText = "";
            this.Haslo_TxtBox.FillColor = System.Drawing.Color.White;
            this.Haslo_TxtBox.HideSelection = true;
            this.Haslo_TxtBox.IconLeft = null;
            this.Haslo_TxtBox.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.Haslo_TxtBox.IconPadding = 10;
            this.Haslo_TxtBox.IconRight = null;
            this.Haslo_TxtBox.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.Haslo_TxtBox.Location = new System.Drawing.Point(181, 297);
            this.Haslo_TxtBox.MaxLength = 32767;
            this.Haslo_TxtBox.MinimumSize = new System.Drawing.Size(100, 35);
            this.Haslo_TxtBox.Modified = false;
            this.Haslo_TxtBox.Name = "Haslo_TxtBox";
            this.Haslo_TxtBox.PasswordChar = '\0';
            this.Haslo_TxtBox.ReadOnly = false;
            this.Haslo_TxtBox.SelectedText = "";
            this.Haslo_TxtBox.SelectionLength = 0;
            this.Haslo_TxtBox.SelectionStart = 0;
            this.Haslo_TxtBox.ShortcutsEnabled = true;
            this.Haslo_TxtBox.Size = new System.Drawing.Size(200, 35);
            this.Haslo_TxtBox.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.Haslo_TxtBox.TabIndex = 2;
            this.Haslo_TxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Haslo_TxtBox.TextMarginLeft = 5;
            this.Haslo_TxtBox.TextPlaceholder = "";
            this.Haslo_TxtBox.UseSystemPasswordChar = false;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = null;
            this.bunifuLabel1.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel1.Location = new System.Drawing.Point(124, 224);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(46, 23);
            this.bunifuLabel1.TabIndex = 3;
            this.bunifuLabel1.Text = "Login";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = null;
            this.bunifuLabel2.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel2.Location = new System.Drawing.Point(124, 297);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(51, 23);
            this.bunifuLabel2.TabIndex = 4;
            this.bunifuLabel2.Text = "Hasło";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.glowa;
            this.bunifuDragControl1.Vertical = true;
            // 
            // Check_Butt
            // 
            this.Check_Butt.ActiveBorderThickness = 1;
            this.Check_Butt.ActiveCornerRadius = 20;
            this.Check_Butt.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.Check_Butt.ActiveForecolor = System.Drawing.Color.White;
            this.Check_Butt.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.Check_Butt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.Check_Butt.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Check_Butt.BackgroundImage")));
            this.Check_Butt.ButtonText = "Zaloguj";
            this.Check_Butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Check_Butt.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Check_Butt.ForeColor = System.Drawing.Color.SeaGreen;
            this.Check_Butt.IdleBorderThickness = 1;
            this.Check_Butt.IdleCornerRadius = 20;
            this.Check_Butt.IdleFillColor = System.Drawing.Color.SandyBrown;
            this.Check_Butt.IdleForecolor = System.Drawing.Color.White;
            this.Check_Butt.IdleLineColor = System.Drawing.Color.White;
            this.Check_Butt.Location = new System.Drawing.Point(157, 395);
            this.Check_Butt.Margin = new System.Windows.Forms.Padding(5);
            this.Check_Butt.Name = "Check_Butt";
            this.Check_Butt.Size = new System.Drawing.Size(249, 49);
            this.Check_Butt.TabIndex = 12;
            this.Check_Butt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Check_Butt.Click += new System.EventHandler(this.Check_Butt_Click);
            // 
            // minimalize
            // 
            this.minimalize.ActiveImage = null;
            this.minimalize.AllowAnimations = true;
            this.minimalize.AllowZooming = true;
            this.minimalize.BackColor = System.Drawing.Color.Transparent;
            this.minimalize.ErrorImage = ((System.Drawing.Image)(resources.GetObject("minimalize.ErrorImage")));
            this.minimalize.FadeWhenInactive = false;
            this.minimalize.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.minimalize.Image = ((System.Drawing.Image)(resources.GetObject("minimalize.Image")));
            this.minimalize.ImageActive = null;
            this.minimalize.ImageLocation = null;
            this.minimalize.ImageMargin = 0;
            this.minimalize.ImageSize = new System.Drawing.Size(37, 34);
            this.minimalize.ImageZoomSize = new System.Drawing.Size(37, 34);
            this.minimalize.InitialImage = ((System.Drawing.Image)(resources.GetObject("minimalize.InitialImage")));
            this.minimalize.Location = new System.Drawing.Point(439, 27);
            this.minimalize.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.minimalize.Name = "minimalize";
            this.minimalize.Rotation = 0;
            this.minimalize.ShowActiveImage = true;
            this.minimalize.ShowCursorChanges = true;
            this.minimalize.ShowImageBorders = false;
            this.minimalize.ShowSizeMarkers = false;
            this.minimalize.Size = new System.Drawing.Size(37, 34);
            this.minimalize.TabIndex = 10;
            this.minimalize.ToolTipText = "";
            this.minimalize.WaitOnLoad = false;
            this.minimalize.Zoom = 0;
            this.minimalize.ZoomSpeed = 10;
            this.minimalize.Click += new System.EventHandler(this.minimalize_Click);
            // 
            // close
            // 
            this.close.ActiveImage = null;
            this.close.AllowAnimations = true;
            this.close.AllowZooming = true;
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.ErrorImage = ((System.Drawing.Image)(resources.GetObject("close.ErrorImage")));
            this.close.FadeWhenInactive = false;
            this.close.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.close.Image = ((System.Drawing.Image)(resources.GetObject("close.Image")));
            this.close.ImageActive = null;
            this.close.ImageLocation = null;
            this.close.ImageMargin = 0;
            this.close.ImageSize = new System.Drawing.Size(37, 34);
            this.close.ImageZoomSize = new System.Drawing.Size(37, 34);
            this.close.InitialImage = ((System.Drawing.Image)(resources.GetObject("close.InitialImage")));
            this.close.Location = new System.Drawing.Point(484, 27);
            this.close.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.close.Name = "close";
            this.close.Rotation = 0;
            this.close.ShowActiveImage = true;
            this.close.ShowCursorChanges = true;
            this.close.ShowImageBorders = false;
            this.close.ShowSizeMarkers = false;
            this.close.Size = new System.Drawing.Size(37, 34);
            this.close.TabIndex = 9;
            this.close.ToolTipText = "";
            this.close.WaitOnLoad = false;
            this.close.Zoom = 0;
            this.close.ZoomSpeed = 10;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // Logowanie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.ClientSize = new System.Drawing.Size(548, 556);
            this.Controls.Add(this.Check_Butt);
            this.Controls.Add(this.bunifuLabel2);
            this.Controls.Add(this.bunifuLabel1);
            this.Controls.Add(this.Haslo_TxtBox);
            this.Controls.Add(this.Login_TxtBox);
            this.Controls.Add(this.glowa);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Logowanie";
            this.Text = "Logowanie";
            this.glowa.ResumeLayout(false);
            this.glowa.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel glowa;
        private System.Windows.Forms.Label label1;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox Haslo_TxtBox;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox Login_TxtBox;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Bunifu.Framework.UI.BunifuThinButton2 Check_Butt;
        private Bunifu.UI.WinForms.BunifuImageButton minimalize;
        private Bunifu.UI.WinForms.BunifuImageButton close;
    }
}