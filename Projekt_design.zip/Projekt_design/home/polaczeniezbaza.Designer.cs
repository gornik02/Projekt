﻿namespace home
{
    partial class polaczeniezbaza
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(polaczeniezbaza));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            this.nazwaserwera = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.nazwauzytkownika = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.haslo = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.nazwabazy = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.nazwabazyzpracownikami = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.nazwabazyzksiegowymi = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.nazwabazyzezwolnieniami = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.lacz = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.res = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse3 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.Rozlacz = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.Reset = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.Polacz = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.red_yellow_green = new System.Windows.Forms.Panel();
            this.bunifuLabel8 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel7 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel6 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel5 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuTextBox7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuTextBox6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuTextBox5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuTextBox4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuTextBox3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuTextBox2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuTextBox1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.SuspendLayout();
            // 
            // nazwaserwera
            // 
            this.nazwaserwera.ElipseRadius = 10;
            // 
            // nazwauzytkownika
            // 
            this.nazwauzytkownika.ElipseRadius = 10;
            // 
            // haslo
            // 
            this.haslo.ElipseRadius = 10;
            // 
            // nazwabazy
            // 
            this.nazwabazy.ElipseRadius = 10;
            // 
            // nazwabazyzpracownikami
            // 
            this.nazwabazyzpracownikami.ElipseRadius = 10;
            // 
            // nazwabazyzksiegowymi
            // 
            this.nazwabazyzksiegowymi.ElipseRadius = 10;
            // 
            // nazwabazyzezwolnieniami
            // 
            this.nazwabazyzezwolnieniami.ElipseRadius = 10;
            // 
            // lacz
            // 
            this.lacz.ElipseRadius = 20;
            // 
            // res
            // 
            this.res.ElipseRadius = 20;
            // 
            // bunifuElipse3
            // 
            this.bunifuElipse3.ElipseRadius = 20;
            // 
            // Rozlacz
            // 
            this.Rozlacz.BackColor = System.Drawing.Color.Transparent;
            this.Rozlacz.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Rozlacz.BackgroundImage")));
            this.Rozlacz.ButtonText = "Rozłącz";
            this.Rozlacz.ButtonTextMarginLeft = 0;
            this.Rozlacz.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Rozlacz.DisabledFillColor = System.Drawing.Color.Gray;
            this.Rozlacz.DisabledForecolor = System.Drawing.Color.White;
            this.Rozlacz.ForeColor = System.Drawing.Color.White;
            this.Rozlacz.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.Rozlacz.IconPadding = 10;
            this.Rozlacz.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.Rozlacz.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.Rozlacz.IdleBorderRadius = 1;
            this.Rozlacz.IdleBorderThickness = 0;
            this.Rozlacz.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.Rozlacz.IdleIconLeftImage = null;
            this.Rozlacz.IdleIconRightImage = null;
            this.Rozlacz.Location = new System.Drawing.Point(476, 431);
            this.Rozlacz.Name = "Rozlacz";
            stateProperties1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties1.BorderRadius = 1;
            stateProperties1.BorderThickness = 1;
            stateProperties1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties1.IconLeftImage = null;
            stateProperties1.IconRightImage = null;
            this.Rozlacz.onHoverState = stateProperties1;
            this.Rozlacz.Size = new System.Drawing.Size(173, 35);
            this.Rozlacz.TabIndex = 77;
            this.Rozlacz.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Reset
            // 
            this.Reset.BackColor = System.Drawing.Color.Transparent;
            this.Reset.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Reset.BackgroundImage")));
            this.Reset.ButtonText = "Reset";
            this.Reset.ButtonTextMarginLeft = 0;
            this.Reset.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Reset.DisabledFillColor = System.Drawing.Color.Gray;
            this.Reset.DisabledForecolor = System.Drawing.Color.White;
            this.Reset.ForeColor = System.Drawing.Color.White;
            this.Reset.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.Reset.IconPadding = 10;
            this.Reset.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.Reset.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.Reset.IdleBorderRadius = 1;
            this.Reset.IdleBorderThickness = 0;
            this.Reset.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.Reset.IdleIconLeftImage = null;
            this.Reset.IdleIconRightImage = null;
            this.Reset.Location = new System.Drawing.Point(277, 431);
            this.Reset.Name = "Reset";
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties2.BorderRadius = 1;
            stateProperties2.BorderThickness = 1;
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties2.IconLeftImage = null;
            stateProperties2.IconRightImage = null;
            this.Reset.onHoverState = stateProperties2;
            this.Reset.Size = new System.Drawing.Size(173, 35);
            this.Reset.TabIndex = 76;
            this.Reset.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Polacz
            // 
            this.Polacz.BackColor = System.Drawing.Color.Transparent;
            this.Polacz.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Polacz.BackgroundImage")));
            this.Polacz.ButtonText = "Połącz";
            this.Polacz.ButtonTextMarginLeft = 0;
            this.Polacz.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Polacz.DisabledFillColor = System.Drawing.Color.Gray;
            this.Polacz.DisabledForecolor = System.Drawing.Color.White;
            this.Polacz.ForeColor = System.Drawing.Color.White;
            this.Polacz.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.Polacz.IconPadding = 10;
            this.Polacz.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.Polacz.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.Polacz.IdleBorderRadius = 1;
            this.Polacz.IdleBorderThickness = 0;
            this.Polacz.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.Polacz.IdleIconLeftImage = null;
            this.Polacz.IdleIconRightImage = null;
            this.Polacz.Location = new System.Drawing.Point(80, 431);
            this.Polacz.Name = "Polacz";
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties3.BorderRadius = 1;
            stateProperties3.BorderThickness = 1;
            stateProperties3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties3.IconLeftImage = null;
            stateProperties3.IconRightImage = null;
            this.Polacz.onHoverState = stateProperties3;
            this.Polacz.Size = new System.Drawing.Size(173, 35);
            this.Polacz.TabIndex = 75;
            this.Polacz.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // red_yellow_green
            // 
            this.red_yellow_green.BackColor = System.Drawing.Color.Red;
            this.red_yellow_green.Location = new System.Drawing.Point(822, 108);
            this.red_yellow_green.Margin = new System.Windows.Forms.Padding(4);
            this.red_yellow_green.Name = "red_yellow_green";
            this.red_yellow_green.Size = new System.Drawing.Size(33, 31);
            this.red_yellow_green.TabIndex = 74;
            // 
            // bunifuLabel8
            // 
            this.bunifuLabel8.AutoEllipsis = false;
            this.bunifuLabel8.CursorType = null;
            this.bunifuLabel8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bunifuLabel8.Location = new System.Drawing.Point(770, 108);
            this.bunifuLabel8.Name = "bunifuLabel8";
            this.bunifuLabel8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel8.Size = new System.Drawing.Size(45, 22);
            this.bunifuLabel8.TabIndex = 73;
            this.bunifuLabel8.Text = "Status";
            this.bunifuLabel8.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel8.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel7
            // 
            this.bunifuLabel7.AutoEllipsis = false;
            this.bunifuLabel7.CursorType = null;
            this.bunifuLabel7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bunifuLabel7.Location = new System.Drawing.Point(440, 305);
            this.bunifuLabel7.Name = "bunifuLabel7";
            this.bunifuLabel7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel7.Size = new System.Drawing.Size(209, 22);
            this.bunifuLabel7.TabIndex = 72;
            this.bunifuLabel7.Text = "Nazwa bazy ze zwolnieniami";
            this.bunifuLabel7.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel7.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel6
            // 
            this.bunifuLabel6.AutoEllipsis = false;
            this.bunifuLabel6.CursorType = null;
            this.bunifuLabel6.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bunifuLabel6.Location = new System.Drawing.Point(458, 264);
            this.bunifuLabel6.Name = "bunifuLabel6";
            this.bunifuLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel6.Size = new System.Drawing.Size(191, 22);
            this.bunifuLabel6.TabIndex = 71;
            this.bunifuLabel6.Text = "Nazwa bazy z księgowymi";
            this.bunifuLabel6.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel6.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel5
            // 
            this.bunifuLabel5.AutoEllipsis = false;
            this.bunifuLabel5.CursorType = null;
            this.bunifuLabel5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bunifuLabel5.Location = new System.Drawing.Point(438, 223);
            this.bunifuLabel5.Name = "bunifuLabel5";
            this.bunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel5.Size = new System.Drawing.Size(211, 22);
            this.bunifuLabel5.TabIndex = 70;
            this.bunifuLabel5.Text = "Nazwa bazy z pracownikami";
            this.bunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel5.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.CursorType = null;
            this.bunifuLabel4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bunifuLabel4.Location = new System.Drawing.Point(47, 305);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(152, 22);
            this.bunifuLabel4.TabIndex = 69;
            this.bunifuLabel4.Text = "Nazwa Bazy Danych";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.CursorType = null;
            this.bunifuLabel3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bunifuLabel3.Location = new System.Drawing.Point(156, 264);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(43, 22);
            this.bunifuLabel3.TabIndex = 68;
            this.bunifuLabel3.Text = "Hasło";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = null;
            this.bunifuLabel2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bunifuLabel2.Location = new System.Drawing.Point(49, 223);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(150, 22);
            this.bunifuLabel2.TabIndex = 67;
            this.bunifuLabel2.Text = "Nazwa Użytkownika";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = null;
            this.bunifuLabel1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bunifuLabel1.Location = new System.Drawing.Point(80, 182);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(119, 22);
            this.bunifuLabel1.TabIndex = 66;
            this.bunifuLabel1.Text = "Nazwa Serwera";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuTextBox7
            // 
            this.bunifuTextBox7.AcceptsReturn = false;
            this.bunifuTextBox7.AcceptsTab = false;
            this.bunifuTextBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox7.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox7.BackgroundImage")));
            this.bunifuTextBox7.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.bunifuTextBox7.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuTextBox7.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.bunifuTextBox7.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.bunifuTextBox7.BorderRadius = 1;
            this.bunifuTextBox7.BorderThickness = 2;
            this.bunifuTextBox7.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox7.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bunifuTextBox7.DefaultText = "";
            this.bunifuTextBox7.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox7.HideSelection = true;
            this.bunifuTextBox7.IconLeft = null;
            this.bunifuTextBox7.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox7.IconPadding = 10;
            this.bunifuTextBox7.IconRight = null;
            this.bunifuTextBox7.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox7.Location = new System.Drawing.Point(655, 305);
            this.bunifuTextBox7.MaxLength = 32767;
            this.bunifuTextBox7.MinimumSize = new System.Drawing.Size(100, 35);
            this.bunifuTextBox7.Modified = false;
            this.bunifuTextBox7.Name = "bunifuTextBox7";
            this.bunifuTextBox7.PasswordChar = '\0';
            this.bunifuTextBox7.ReadOnly = false;
            this.bunifuTextBox7.SelectedText = "";
            this.bunifuTextBox7.SelectionLength = 0;
            this.bunifuTextBox7.SelectionStart = 0;
            this.bunifuTextBox7.ShortcutsEnabled = true;
            this.bunifuTextBox7.Size = new System.Drawing.Size(200, 35);
            this.bunifuTextBox7.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox7.TabIndex = 65;
            this.bunifuTextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox7.TextMarginLeft = 5;
            this.bunifuTextBox7.TextPlaceholder = "";
            this.bunifuTextBox7.UseSystemPasswordChar = false;
            // 
            // bunifuTextBox6
            // 
            this.bunifuTextBox6.AcceptsReturn = false;
            this.bunifuTextBox6.AcceptsTab = false;
            this.bunifuTextBox6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox6.BackgroundImage")));
            this.bunifuTextBox6.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.bunifuTextBox6.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuTextBox6.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.bunifuTextBox6.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.bunifuTextBox6.BorderRadius = 1;
            this.bunifuTextBox6.BorderThickness = 2;
            this.bunifuTextBox6.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox6.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bunifuTextBox6.DefaultText = "";
            this.bunifuTextBox6.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox6.HideSelection = true;
            this.bunifuTextBox6.IconLeft = null;
            this.bunifuTextBox6.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox6.IconPadding = 10;
            this.bunifuTextBox6.IconRight = null;
            this.bunifuTextBox6.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox6.Location = new System.Drawing.Point(655, 264);
            this.bunifuTextBox6.MaxLength = 32767;
            this.bunifuTextBox6.MinimumSize = new System.Drawing.Size(100, 35);
            this.bunifuTextBox6.Modified = false;
            this.bunifuTextBox6.Name = "bunifuTextBox6";
            this.bunifuTextBox6.PasswordChar = '\0';
            this.bunifuTextBox6.ReadOnly = false;
            this.bunifuTextBox6.SelectedText = "";
            this.bunifuTextBox6.SelectionLength = 0;
            this.bunifuTextBox6.SelectionStart = 0;
            this.bunifuTextBox6.ShortcutsEnabled = true;
            this.bunifuTextBox6.Size = new System.Drawing.Size(200, 35);
            this.bunifuTextBox6.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox6.TabIndex = 64;
            this.bunifuTextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox6.TextMarginLeft = 5;
            this.bunifuTextBox6.TextPlaceholder = "";
            this.bunifuTextBox6.UseSystemPasswordChar = false;
            // 
            // bunifuTextBox5
            // 
            this.bunifuTextBox5.AcceptsReturn = false;
            this.bunifuTextBox5.AcceptsTab = false;
            this.bunifuTextBox5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox5.BackgroundImage")));
            this.bunifuTextBox5.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.bunifuTextBox5.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuTextBox5.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.bunifuTextBox5.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.bunifuTextBox5.BorderRadius = 1;
            this.bunifuTextBox5.BorderThickness = 2;
            this.bunifuTextBox5.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox5.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bunifuTextBox5.DefaultText = "";
            this.bunifuTextBox5.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox5.HideSelection = true;
            this.bunifuTextBox5.IconLeft = null;
            this.bunifuTextBox5.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox5.IconPadding = 10;
            this.bunifuTextBox5.IconRight = null;
            this.bunifuTextBox5.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox5.Location = new System.Drawing.Point(655, 223);
            this.bunifuTextBox5.MaxLength = 32767;
            this.bunifuTextBox5.MinimumSize = new System.Drawing.Size(100, 35);
            this.bunifuTextBox5.Modified = false;
            this.bunifuTextBox5.Name = "bunifuTextBox5";
            this.bunifuTextBox5.PasswordChar = '\0';
            this.bunifuTextBox5.ReadOnly = false;
            this.bunifuTextBox5.SelectedText = "";
            this.bunifuTextBox5.SelectionLength = 0;
            this.bunifuTextBox5.SelectionStart = 0;
            this.bunifuTextBox5.ShortcutsEnabled = true;
            this.bunifuTextBox5.Size = new System.Drawing.Size(200, 35);
            this.bunifuTextBox5.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox5.TabIndex = 63;
            this.bunifuTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox5.TextMarginLeft = 5;
            this.bunifuTextBox5.TextPlaceholder = "";
            this.bunifuTextBox5.UseSystemPasswordChar = false;
            // 
            // bunifuTextBox4
            // 
            this.bunifuTextBox4.AcceptsReturn = false;
            this.bunifuTextBox4.AcceptsTab = false;
            this.bunifuTextBox4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox4.BackgroundImage")));
            this.bunifuTextBox4.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.bunifuTextBox4.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuTextBox4.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.bunifuTextBox4.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.bunifuTextBox4.BorderRadius = 1;
            this.bunifuTextBox4.BorderThickness = 2;
            this.bunifuTextBox4.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox4.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bunifuTextBox4.DefaultText = "";
            this.bunifuTextBox4.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox4.HideSelection = true;
            this.bunifuTextBox4.IconLeft = null;
            this.bunifuTextBox4.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox4.IconPadding = 10;
            this.bunifuTextBox4.IconRight = null;
            this.bunifuTextBox4.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox4.Location = new System.Drawing.Point(205, 305);
            this.bunifuTextBox4.MaxLength = 32767;
            this.bunifuTextBox4.MinimumSize = new System.Drawing.Size(100, 35);
            this.bunifuTextBox4.Modified = false;
            this.bunifuTextBox4.Name = "bunifuTextBox4";
            this.bunifuTextBox4.PasswordChar = '\0';
            this.bunifuTextBox4.ReadOnly = false;
            this.bunifuTextBox4.SelectedText = "";
            this.bunifuTextBox4.SelectionLength = 0;
            this.bunifuTextBox4.SelectionStart = 0;
            this.bunifuTextBox4.ShortcutsEnabled = true;
            this.bunifuTextBox4.Size = new System.Drawing.Size(200, 35);
            this.bunifuTextBox4.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox4.TabIndex = 62;
            this.bunifuTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox4.TextMarginLeft = 5;
            this.bunifuTextBox4.TextPlaceholder = "";
            this.bunifuTextBox4.UseSystemPasswordChar = false;
            // 
            // bunifuTextBox3
            // 
            this.bunifuTextBox3.AcceptsReturn = false;
            this.bunifuTextBox3.AcceptsTab = false;
            this.bunifuTextBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox3.BackgroundImage")));
            this.bunifuTextBox3.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.bunifuTextBox3.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuTextBox3.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.bunifuTextBox3.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.bunifuTextBox3.BorderRadius = 1;
            this.bunifuTextBox3.BorderThickness = 2;
            this.bunifuTextBox3.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox3.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bunifuTextBox3.DefaultText = "";
            this.bunifuTextBox3.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox3.HideSelection = true;
            this.bunifuTextBox3.IconLeft = null;
            this.bunifuTextBox3.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox3.IconPadding = 10;
            this.bunifuTextBox3.IconRight = null;
            this.bunifuTextBox3.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox3.Location = new System.Drawing.Point(205, 264);
            this.bunifuTextBox3.MaxLength = 32767;
            this.bunifuTextBox3.MinimumSize = new System.Drawing.Size(100, 35);
            this.bunifuTextBox3.Modified = false;
            this.bunifuTextBox3.Name = "bunifuTextBox3";
            this.bunifuTextBox3.PasswordChar = '\0';
            this.bunifuTextBox3.ReadOnly = false;
            this.bunifuTextBox3.SelectedText = "";
            this.bunifuTextBox3.SelectionLength = 0;
            this.bunifuTextBox3.SelectionStart = 0;
            this.bunifuTextBox3.ShortcutsEnabled = true;
            this.bunifuTextBox3.Size = new System.Drawing.Size(200, 35);
            this.bunifuTextBox3.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox3.TabIndex = 61;
            this.bunifuTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox3.TextMarginLeft = 5;
            this.bunifuTextBox3.TextPlaceholder = "";
            this.bunifuTextBox3.UseSystemPasswordChar = false;
            // 
            // bunifuTextBox2
            // 
            this.bunifuTextBox2.AcceptsReturn = false;
            this.bunifuTextBox2.AcceptsTab = false;
            this.bunifuTextBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox2.BackgroundImage")));
            this.bunifuTextBox2.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.bunifuTextBox2.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuTextBox2.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.bunifuTextBox2.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.bunifuTextBox2.BorderRadius = 1;
            this.bunifuTextBox2.BorderThickness = 2;
            this.bunifuTextBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox2.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bunifuTextBox2.DefaultText = "";
            this.bunifuTextBox2.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox2.HideSelection = true;
            this.bunifuTextBox2.IconLeft = null;
            this.bunifuTextBox2.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox2.IconPadding = 10;
            this.bunifuTextBox2.IconRight = null;
            this.bunifuTextBox2.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox2.Location = new System.Drawing.Point(205, 223);
            this.bunifuTextBox2.MaxLength = 32767;
            this.bunifuTextBox2.MinimumSize = new System.Drawing.Size(100, 35);
            this.bunifuTextBox2.Modified = false;
            this.bunifuTextBox2.Name = "bunifuTextBox2";
            this.bunifuTextBox2.PasswordChar = '\0';
            this.bunifuTextBox2.ReadOnly = false;
            this.bunifuTextBox2.SelectedText = "";
            this.bunifuTextBox2.SelectionLength = 0;
            this.bunifuTextBox2.SelectionStart = 0;
            this.bunifuTextBox2.ShortcutsEnabled = true;
            this.bunifuTextBox2.Size = new System.Drawing.Size(200, 35);
            this.bunifuTextBox2.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox2.TabIndex = 60;
            this.bunifuTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox2.TextMarginLeft = 5;
            this.bunifuTextBox2.TextPlaceholder = "";
            this.bunifuTextBox2.UseSystemPasswordChar = false;
            // 
            // bunifuTextBox1
            // 
            this.bunifuTextBox1.AcceptsReturn = false;
            this.bunifuTextBox1.AcceptsTab = false;
            this.bunifuTextBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox1.BackgroundImage")));
            this.bunifuTextBox1.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.bunifuTextBox1.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuTextBox1.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.bunifuTextBox1.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.bunifuTextBox1.BorderRadius = 1;
            this.bunifuTextBox1.BorderThickness = 2;
            this.bunifuTextBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox1.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bunifuTextBox1.DefaultText = "";
            this.bunifuTextBox1.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox1.HideSelection = true;
            this.bunifuTextBox1.IconLeft = null;
            this.bunifuTextBox1.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox1.IconPadding = 10;
            this.bunifuTextBox1.IconRight = null;
            this.bunifuTextBox1.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox1.Location = new System.Drawing.Point(205, 182);
            this.bunifuTextBox1.MaxLength = 32767;
            this.bunifuTextBox1.MinimumSize = new System.Drawing.Size(100, 35);
            this.bunifuTextBox1.Modified = false;
            this.bunifuTextBox1.Name = "bunifuTextBox1";
            this.bunifuTextBox1.PasswordChar = '\0';
            this.bunifuTextBox1.ReadOnly = false;
            this.bunifuTextBox1.SelectedText = "";
            this.bunifuTextBox1.SelectionLength = 0;
            this.bunifuTextBox1.SelectionStart = 0;
            this.bunifuTextBox1.ShortcutsEnabled = true;
            this.bunifuTextBox1.Size = new System.Drawing.Size(200, 35);
            this.bunifuTextBox1.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox1.TabIndex = 59;
            this.bunifuTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox1.TextMarginLeft = 5;
            this.bunifuTextBox1.TextPlaceholder = "";
            this.bunifuTextBox1.UseSystemPasswordChar = false;
            // 
            // polaczeniezbaza
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.Controls.Add(this.Rozlacz);
            this.Controls.Add(this.Reset);
            this.Controls.Add(this.Polacz);
            this.Controls.Add(this.red_yellow_green);
            this.Controls.Add(this.bunifuLabel8);
            this.Controls.Add(this.bunifuLabel7);
            this.Controls.Add(this.bunifuLabel6);
            this.Controls.Add(this.bunifuLabel5);
            this.Controls.Add(this.bunifuLabel4);
            this.Controls.Add(this.bunifuLabel3);
            this.Controls.Add(this.bunifuLabel2);
            this.Controls.Add(this.bunifuLabel1);
            this.Controls.Add(this.bunifuTextBox7);
            this.Controls.Add(this.bunifuTextBox6);
            this.Controls.Add(this.bunifuTextBox5);
            this.Controls.Add(this.bunifuTextBox4);
            this.Controls.Add(this.bunifuTextBox3);
            this.Controls.Add(this.bunifuTextBox2);
            this.Controls.Add(this.bunifuTextBox1);
            this.Name = "polaczeniezbaza";
            this.Size = new System.Drawing.Size(902, 575);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Bunifu.Framework.UI.BunifuElipse nazwaserwera;
        private Bunifu.Framework.UI.BunifuElipse nazwauzytkownika;
        private Bunifu.Framework.UI.BunifuElipse haslo;
        private Bunifu.Framework.UI.BunifuElipse nazwabazy;
        private Bunifu.Framework.UI.BunifuElipse nazwabazyzpracownikami;
        private Bunifu.Framework.UI.BunifuElipse nazwabazyzksiegowymi;
        private Bunifu.Framework.UI.BunifuElipse nazwabazyzezwolnieniami;
        private Bunifu.Framework.UI.BunifuElipse lacz;
        private Bunifu.Framework.UI.BunifuElipse res;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse3;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton Rozlacz;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton Reset;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton Polacz;
        private System.Windows.Forms.Panel red_yellow_green;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel8;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel7;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel6;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel5;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox bunifuTextBox7;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox bunifuTextBox6;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox bunifuTextBox5;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox bunifuTextBox4;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox bunifuTextBox3;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox bunifuTextBox2;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox bunifuTextBox1;
    }
}
