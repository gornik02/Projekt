﻿namespace home
{
    partial class Add_Form_Pracownik
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Add_Form_Pracownik));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.header = new System.Windows.Forms.Panel();
            this.minimalize = new Bunifu.UI.WinForms.BunifuImageButton();
            this.close = new Bunifu.UI.WinForms.BunifuImageButton();
            this.label1 = new System.Windows.Forms.Label();
            this.bunifuCheckbox1 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckBox2 = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.bunifuDragControl4 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.Imie = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.Naz = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.Pesel = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.PlecM = new System.Windows.Forms.RadioButton();
            this.PlecK = new System.Windows.Forms.RadioButton();
            this.Stanow = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.StudentTak = new System.Windows.Forms.RadioButton();
            this.StudentNie = new System.Windows.Forms.RadioButton();
            this.RodzajZat = new System.Windows.Forms.ComboBox();
            this.pensja_netto = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.Enter = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel5 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel6 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel7 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel8 = new Bunifu.UI.WinForms.BunifuLabel();
            this.header.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // header
            // 
            this.header.BackColor = System.Drawing.Color.White;
            this.header.Controls.Add(this.minimalize);
            this.header.Controls.Add(this.close);
            this.header.Controls.Add(this.label1);
            this.header.Dock = System.Windows.Forms.DockStyle.Top;
            this.header.Location = new System.Drawing.Point(0, 0);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(595, 93);
            this.header.TabIndex = 0;
            // 
            // minimalize
            // 
            this.minimalize.ActiveImage = null;
            this.minimalize.AllowAnimations = true;
            this.minimalize.AllowZooming = true;
            this.minimalize.BackColor = System.Drawing.Color.Transparent;
            this.minimalize.ErrorImage = ((System.Drawing.Image)(resources.GetObject("minimalize.ErrorImage")));
            this.minimalize.FadeWhenInactive = false;
            this.minimalize.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.minimalize.Image = ((System.Drawing.Image)(resources.GetObject("minimalize.Image")));
            this.minimalize.ImageActive = null;
            this.minimalize.ImageLocation = null;
            this.minimalize.ImageMargin = 0;
            this.minimalize.ImageSize = new System.Drawing.Size(37, 34);
            this.minimalize.ImageZoomSize = new System.Drawing.Size(37, 34);
            this.minimalize.InitialImage = ((System.Drawing.Image)(resources.GetObject("minimalize.InitialImage")));
            this.minimalize.Location = new System.Drawing.Point(489, 26);
            this.minimalize.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.minimalize.Name = "minimalize";
            this.minimalize.Rotation = 0;
            this.minimalize.ShowActiveImage = true;
            this.minimalize.ShowCursorChanges = true;
            this.minimalize.ShowImageBorders = false;
            this.minimalize.ShowSizeMarkers = false;
            this.minimalize.Size = new System.Drawing.Size(37, 34);
            this.minimalize.TabIndex = 14;
            this.minimalize.ToolTipText = "";
            this.minimalize.WaitOnLoad = false;
            this.minimalize.Zoom = 0;
            this.minimalize.ZoomSpeed = 10;
            this.minimalize.Click += new System.EventHandler(this.minimalize_Click);
            // 
            // close
            // 
            this.close.ActiveImage = null;
            this.close.AllowAnimations = true;
            this.close.AllowZooming = true;
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.ErrorImage = ((System.Drawing.Image)(resources.GetObject("close.ErrorImage")));
            this.close.FadeWhenInactive = false;
            this.close.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.close.Image = ((System.Drawing.Image)(resources.GetObject("close.Image")));
            this.close.ImageActive = null;
            this.close.ImageLocation = null;
            this.close.ImageMargin = 0;
            this.close.ImageSize = new System.Drawing.Size(37, 34);
            this.close.ImageZoomSize = new System.Drawing.Size(37, 34);
            this.close.InitialImage = ((System.Drawing.Image)(resources.GetObject("close.InitialImage")));
            this.close.Location = new System.Drawing.Point(534, 26);
            this.close.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.close.Name = "close";
            this.close.Rotation = 0;
            this.close.ShowActiveImage = true;
            this.close.ShowCursorChanges = true;
            this.close.ShowImageBorders = false;
            this.close.ShowSizeMarkers = false;
            this.close.Size = new System.Drawing.Size(37, 34);
            this.close.TabIndex = 13;
            this.close.ToolTipText = "";
            this.close.WaitOnLoad = false;
            this.close.Zoom = 0;
            this.close.ZoomSpeed = 10;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Book Antiqua", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(61, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 34);
            this.label1.TabIndex = 12;
            this.label1.Text = "Księgowy IO";
            // 
            // bunifuCheckbox1
            // 
            this.bunifuCheckbox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox1.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox1.Checked = true;
            this.bunifuCheckbox1.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox1.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox1.Location = new System.Drawing.Point(-19, -19);
            this.bunifuCheckbox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuCheckbox1.Name = "bunifuCheckbox1";
            this.bunifuCheckbox1.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox1.TabIndex = 1;
            // 
            // bunifuCheckBox2
            // 
            this.bunifuCheckBox2.AllowBindingControlAnimation = true;
            this.bunifuCheckBox2.AllowBindingControlColorChanges = false;
            this.bunifuCheckBox2.AllowBindingControlLocation = true;
            this.bunifuCheckBox2.AllowCheckBoxAnimation = false;
            this.bunifuCheckBox2.AllowCheckmarkAnimation = true;
            this.bunifuCheckBox2.AllowOnHoverStates = true;
            this.bunifuCheckBox2.AutoCheck = true;
            this.bunifuCheckBox2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCheckBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCheckBox2.BackgroundImage")));
            this.bunifuCheckBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bunifuCheckBox2.BindingControl = null;
            this.bunifuCheckBox2.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.bunifuCheckBox2.Checked = true;
            this.bunifuCheckBox2.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Checked;
            this.bunifuCheckBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuCheckBox2.CustomCheckmarkImage = null;
            this.bunifuCheckBox2.Location = new System.Drawing.Point(-19, -19);
            this.bunifuCheckBox2.MinimumSize = new System.Drawing.Size(17, 17);
            this.bunifuCheckBox2.Name = "bunifuCheckBox2";
            this.bunifuCheckBox2.OnCheck.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(69)))), ((int)(((byte)(155)))));
            this.bunifuCheckBox2.OnCheck.BorderRadius = 2;
            this.bunifuCheckBox2.OnCheck.BorderThickness = 2;
            this.bunifuCheckBox2.OnCheck.CheckBoxColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(69)))), ((int)(((byte)(155)))));
            this.bunifuCheckBox2.OnCheck.CheckmarkColor = System.Drawing.Color.White;
            this.bunifuCheckBox2.OnCheck.CheckmarkThickness = 2;
            this.bunifuCheckBox2.OnDisable.BorderColor = System.Drawing.Color.LightGray;
            this.bunifuCheckBox2.OnDisable.BorderRadius = 2;
            this.bunifuCheckBox2.OnDisable.BorderThickness = 2;
            this.bunifuCheckBox2.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.bunifuCheckBox2.OnDisable.CheckmarkColor = System.Drawing.Color.LightGray;
            this.bunifuCheckBox2.OnDisable.CheckmarkThickness = 2;
            this.bunifuCheckBox2.OnHoverChecked.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(131)))), ((int)(((byte)(188)))));
            this.bunifuCheckBox2.OnHoverChecked.BorderRadius = 2;
            this.bunifuCheckBox2.OnHoverChecked.BorderThickness = 2;
            this.bunifuCheckBox2.OnHoverChecked.CheckBoxColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(131)))), ((int)(((byte)(188)))));
            this.bunifuCheckBox2.OnHoverChecked.CheckmarkColor = System.Drawing.Color.White;
            this.bunifuCheckBox2.OnHoverChecked.CheckmarkThickness = 2;
            this.bunifuCheckBox2.OnHoverUnchecked.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(131)))), ((int)(((byte)(188)))));
            this.bunifuCheckBox2.OnHoverUnchecked.BorderRadius = 2;
            this.bunifuCheckBox2.OnHoverUnchecked.BorderThickness = 2;
            this.bunifuCheckBox2.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.bunifuCheckBox2.OnUncheck.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(69)))), ((int)(((byte)(155)))));
            this.bunifuCheckBox2.OnUncheck.BorderRadius = 2;
            this.bunifuCheckBox2.OnUncheck.BorderThickness = 2;
            this.bunifuCheckBox2.OnUncheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.bunifuCheckBox2.Size = new System.Drawing.Size(21, 21);
            this.bunifuCheckBox2.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Bunifu;
            this.bunifuCheckBox2.TabIndex = 2;
            this.bunifuCheckBox2.ThreeState = false;
            this.bunifuCheckBox2.ToolTipText = null;
            // 
            // bunifuDragControl4
            // 
            this.bunifuDragControl4.Fixed = true;
            this.bunifuDragControl4.Horizontal = true;
            this.bunifuDragControl4.TargetControl = this.header;
            this.bunifuDragControl4.Vertical = true;
            // 
            // Imie
            // 
            this.Imie.AcceptsReturn = false;
            this.Imie.AcceptsTab = false;
            this.Imie.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Imie.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Imie.BackColor = System.Drawing.Color.Transparent;
            this.Imie.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Imie.BackgroundImage")));
            this.Imie.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.Imie.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Imie.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.Imie.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.Imie.BorderRadius = 1;
            this.Imie.BorderThickness = 2;
            this.Imie.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Imie.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Imie.DefaultText = "";
            this.Imie.FillColor = System.Drawing.Color.White;
            this.Imie.HideSelection = true;
            this.Imie.IconLeft = null;
            this.Imie.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.Imie.IconPadding = 10;
            this.Imie.IconRight = null;
            this.Imie.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.Imie.Location = new System.Drawing.Point(252, 127);
            this.Imie.MaxLength = 32767;
            this.Imie.MinimumSize = new System.Drawing.Size(100, 35);
            this.Imie.Modified = false;
            this.Imie.Name = "Imie";
            this.Imie.PasswordChar = '\0';
            this.Imie.ReadOnly = false;
            this.Imie.SelectedText = "";
            this.Imie.SelectionLength = 0;
            this.Imie.SelectionStart = 0;
            this.Imie.ShortcutsEnabled = true;
            this.Imie.Size = new System.Drawing.Size(200, 35);
            this.Imie.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.Imie.TabIndex = 3;
            this.Imie.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Imie.TextMarginLeft = 5;
            this.Imie.TextPlaceholder = "";
            this.Imie.UseSystemPasswordChar = false;
            // 
            // Naz
            // 
            this.Naz.AcceptsReturn = false;
            this.Naz.AcceptsTab = false;
            this.Naz.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Naz.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Naz.BackColor = System.Drawing.Color.Transparent;
            this.Naz.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Naz.BackgroundImage")));
            this.Naz.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.Naz.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Naz.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.Naz.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.Naz.BorderRadius = 1;
            this.Naz.BorderThickness = 2;
            this.Naz.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Naz.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Naz.DefaultText = "";
            this.Naz.FillColor = System.Drawing.Color.White;
            this.Naz.HideSelection = true;
            this.Naz.IconLeft = null;
            this.Naz.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.Naz.IconPadding = 10;
            this.Naz.IconRight = null;
            this.Naz.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.Naz.Location = new System.Drawing.Point(252, 186);
            this.Naz.MaxLength = 32767;
            this.Naz.MinimumSize = new System.Drawing.Size(100, 35);
            this.Naz.Modified = false;
            this.Naz.Name = "Naz";
            this.Naz.PasswordChar = '\0';
            this.Naz.ReadOnly = false;
            this.Naz.SelectedText = "";
            this.Naz.SelectionLength = 0;
            this.Naz.SelectionStart = 0;
            this.Naz.ShortcutsEnabled = true;
            this.Naz.Size = new System.Drawing.Size(200, 35);
            this.Naz.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.Naz.TabIndex = 4;
            this.Naz.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Naz.TextMarginLeft = 5;
            this.Naz.TextPlaceholder = "";
            this.Naz.UseSystemPasswordChar = false;
            // 
            // Pesel
            // 
            this.Pesel.AcceptsReturn = false;
            this.Pesel.AcceptsTab = false;
            this.Pesel.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Pesel.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Pesel.BackColor = System.Drawing.Color.Transparent;
            this.Pesel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Pesel.BackgroundImage")));
            this.Pesel.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.Pesel.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Pesel.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.Pesel.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.Pesel.BorderRadius = 1;
            this.Pesel.BorderThickness = 2;
            this.Pesel.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Pesel.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Pesel.DefaultText = "";
            this.Pesel.FillColor = System.Drawing.Color.White;
            this.Pesel.HideSelection = true;
            this.Pesel.IconLeft = null;
            this.Pesel.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.Pesel.IconPadding = 10;
            this.Pesel.IconRight = null;
            this.Pesel.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.Pesel.Location = new System.Drawing.Point(252, 243);
            this.Pesel.MaxLength = 32767;
            this.Pesel.MinimumSize = new System.Drawing.Size(100, 35);
            this.Pesel.Modified = false;
            this.Pesel.Name = "Pesel";
            this.Pesel.PasswordChar = '\0';
            this.Pesel.ReadOnly = false;
            this.Pesel.SelectedText = "";
            this.Pesel.SelectionLength = 0;
            this.Pesel.SelectionStart = 0;
            this.Pesel.ShortcutsEnabled = true;
            this.Pesel.Size = new System.Drawing.Size(200, 35);
            this.Pesel.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.Pesel.TabIndex = 5;
            this.Pesel.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Pesel.TextMarginLeft = 5;
            this.Pesel.TextPlaceholder = "";
            this.Pesel.UseSystemPasswordChar = false;
            // 
            // PlecM
            // 
            this.PlecM.AutoSize = true;
            this.PlecM.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.PlecM.Location = new System.Drawing.Point(252, 298);
            this.PlecM.Name = "PlecM";
            this.PlecM.Size = new System.Drawing.Size(106, 23);
            this.PlecM.TabIndex = 6;
            this.PlecM.TabStop = true;
            this.PlecM.Text = "Mężczyzna";
            this.PlecM.UseVisualStyleBackColor = true;
            // 
            // PlecK
            // 
            this.PlecK.AutoSize = true;
            this.PlecK.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.PlecK.Location = new System.Drawing.Point(368, 298);
            this.PlecK.Name = "PlecK";
            this.PlecK.Size = new System.Drawing.Size(84, 23);
            this.PlecK.TabIndex = 7;
            this.PlecK.TabStop = true;
            this.PlecK.Text = "Kobieta";
            this.PlecK.UseVisualStyleBackColor = true;
            // 
            // Stanow
            // 
            this.Stanow.AcceptsReturn = false;
            this.Stanow.AcceptsTab = false;
            this.Stanow.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Stanow.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Stanow.BackColor = System.Drawing.Color.Transparent;
            this.Stanow.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Stanow.BackgroundImage")));
            this.Stanow.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.Stanow.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Stanow.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.Stanow.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.Stanow.BorderRadius = 1;
            this.Stanow.BorderThickness = 2;
            this.Stanow.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Stanow.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Stanow.DefaultText = "";
            this.Stanow.FillColor = System.Drawing.Color.White;
            this.Stanow.HideSelection = true;
            this.Stanow.IconLeft = null;
            this.Stanow.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.Stanow.IconPadding = 10;
            this.Stanow.IconRight = null;
            this.Stanow.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.Stanow.Location = new System.Drawing.Point(252, 336);
            this.Stanow.MaxLength = 32767;
            this.Stanow.MinimumSize = new System.Drawing.Size(100, 35);
            this.Stanow.Modified = false;
            this.Stanow.Name = "Stanow";
            this.Stanow.PasswordChar = '\0';
            this.Stanow.ReadOnly = false;
            this.Stanow.SelectedText = "";
            this.Stanow.SelectionLength = 0;
            this.Stanow.SelectionStart = 0;
            this.Stanow.ShortcutsEnabled = true;
            this.Stanow.Size = new System.Drawing.Size(200, 35);
            this.Stanow.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.Stanow.TabIndex = 8;
            this.Stanow.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Stanow.TextMarginLeft = 5;
            this.Stanow.TextPlaceholder = "";
            this.Stanow.UseSystemPasswordChar = false;
            // 
            // StudentTak
            // 
            this.StudentTak.AutoSize = true;
            this.StudentTak.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.StudentTak.Location = new System.Drawing.Point(252, 391);
            this.StudentTak.Name = "StudentTak";
            this.StudentTak.Size = new System.Drawing.Size(52, 23);
            this.StudentTak.TabIndex = 9;
            this.StudentTak.TabStop = true;
            this.StudentTak.Text = "Tak";
            this.StudentTak.UseVisualStyleBackColor = true;
            // 
            // StudentNie
            // 
            this.StudentNie.AutoSize = true;
            this.StudentNie.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.StudentNie.Location = new System.Drawing.Point(310, 391);
            this.StudentNie.Name = "StudentNie";
            this.StudentNie.Size = new System.Drawing.Size(52, 23);
            this.StudentNie.TabIndex = 10;
            this.StudentNie.TabStop = true;
            this.StudentNie.Text = "Nie";
            this.StudentNie.UseVisualStyleBackColor = true;
            // 
            // RodzajZat
            // 
            this.RodzajZat.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RodzajZat.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.RodzajZat.FormattingEnabled = true;
            this.RodzajZat.Location = new System.Drawing.Point(252, 433);
            this.RodzajZat.Name = "RodzajZat";
            this.RodzajZat.Size = new System.Drawing.Size(200, 25);
            this.RodzajZat.TabIndex = 11;
            // 
            // pensja_netto
            // 
            this.pensja_netto.AcceptsReturn = false;
            this.pensja_netto.AcceptsTab = false;
            this.pensja_netto.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.pensja_netto.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.pensja_netto.BackColor = System.Drawing.Color.Transparent;
            this.pensja_netto.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pensja_netto.BackgroundImage")));
            this.pensja_netto.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.pensja_netto.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.pensja_netto.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.pensja_netto.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.pensja_netto.BorderRadius = 1;
            this.pensja_netto.BorderThickness = 2;
            this.pensja_netto.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.pensja_netto.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pensja_netto.DefaultText = "";
            this.pensja_netto.FillColor = System.Drawing.Color.White;
            this.pensja_netto.HideSelection = true;
            this.pensja_netto.IconLeft = null;
            this.pensja_netto.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.pensja_netto.IconPadding = 10;
            this.pensja_netto.IconRight = null;
            this.pensja_netto.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.pensja_netto.Location = new System.Drawing.Point(252, 482);
            this.pensja_netto.MaxLength = 32767;
            this.pensja_netto.MinimumSize = new System.Drawing.Size(100, 35);
            this.pensja_netto.Modified = false;
            this.pensja_netto.Name = "pensja_netto";
            this.pensja_netto.PasswordChar = '\0';
            this.pensja_netto.ReadOnly = false;
            this.pensja_netto.SelectedText = "";
            this.pensja_netto.SelectionLength = 0;
            this.pensja_netto.SelectionStart = 0;
            this.pensja_netto.ShortcutsEnabled = true;
            this.pensja_netto.Size = new System.Drawing.Size(200, 35);
            this.pensja_netto.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.pensja_netto.TabIndex = 12;
            this.pensja_netto.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.pensja_netto.TextMarginLeft = 5;
            this.pensja_netto.TextPlaceholder = "";
            this.pensja_netto.UseSystemPasswordChar = false;
            // 
            // Enter
            // 
            this.Enter.ActiveBorderThickness = 1;
            this.Enter.ActiveCornerRadius = 20;
            this.Enter.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.Enter.ActiveForecolor = System.Drawing.Color.White;
            this.Enter.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.Enter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.Enter.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Enter.BackgroundImage")));
            this.Enter.ButtonText = "Dodaj Osobę";
            this.Enter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Enter.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Enter.ForeColor = System.Drawing.Color.SeaGreen;
            this.Enter.IdleBorderThickness = 1;
            this.Enter.IdleCornerRadius = 20;
            this.Enter.IdleFillColor = System.Drawing.Color.SandyBrown;
            this.Enter.IdleForecolor = System.Drawing.Color.White;
            this.Enter.IdleLineColor = System.Drawing.Color.White;
            this.Enter.Location = new System.Drawing.Point(129, 544);
            this.Enter.Margin = new System.Windows.Forms.Padding(5);
            this.Enter.Name = "Enter";
            this.Enter.Size = new System.Drawing.Size(323, 55);
            this.Enter.TabIndex = 13;
            this.Enter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = null;
            this.bunifuLabel1.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel1.Location = new System.Drawing.Point(209, 127);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(37, 23);
            this.bunifuLabel1.TabIndex = 14;
            this.bunifuLabel1.Text = "Imie";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = null;
            this.bunifuLabel2.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel2.Location = new System.Drawing.Point(167, 186);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(79, 23);
            this.bunifuLabel2.TabIndex = 15;
            this.bunifuLabel2.Text = "Nazwisko";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.CursorType = null;
            this.bunifuLabel3.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel3.Location = new System.Drawing.Point(201, 243);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(45, 23);
            this.bunifuLabel3.TabIndex = 16;
            this.bunifuLabel3.Text = "Pesel";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.CursorType = null;
            this.bunifuLabel4.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel4.Location = new System.Drawing.Point(208, 298);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(38, 23);
            this.bunifuLabel4.TabIndex = 17;
            this.bunifuLabel4.Text = "Plec";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel5
            // 
            this.bunifuLabel5.AutoEllipsis = false;
            this.bunifuLabel5.CursorType = null;
            this.bunifuLabel5.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel5.Location = new System.Drawing.Point(151, 336);
            this.bunifuLabel5.Name = "bunifuLabel5";
            this.bunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel5.Size = new System.Drawing.Size(95, 23);
            this.bunifuLabel5.TabIndex = 18;
            this.bunifuLabel5.Text = "Stanowisko";
            this.bunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel5.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel6
            // 
            this.bunifuLabel6.AutoEllipsis = false;
            this.bunifuLabel6.CursorType = null;
            this.bunifuLabel6.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel6.Location = new System.Drawing.Point(144, 391);
            this.bunifuLabel6.Name = "bunifuLabel6";
            this.bunifuLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel6.Size = new System.Drawing.Size(102, 23);
            this.bunifuLabel6.TabIndex = 19;
            this.bunifuLabel6.Text = "Czy Student";
            this.bunifuLabel6.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel6.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel7
            // 
            this.bunifuLabel7.AutoEllipsis = false;
            this.bunifuLabel7.CursorType = null;
            this.bunifuLabel7.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel7.Location = new System.Drawing.Point(80, 434);
            this.bunifuLabel7.Name = "bunifuLabel7";
            this.bunifuLabel7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel7.Size = new System.Drawing.Size(166, 23);
            this.bunifuLabel7.TabIndex = 20;
            this.bunifuLabel7.Text = "Rodzaj Zatrudnienia";
            this.bunifuLabel7.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel7.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel8
            // 
            this.bunifuLabel8.AutoEllipsis = false;
            this.bunifuLabel8.CursorType = null;
            this.bunifuLabel8.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel8.Location = new System.Drawing.Point(135, 482);
            this.bunifuLabel8.Name = "bunifuLabel8";
            this.bunifuLabel8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel8.Size = new System.Drawing.Size(111, 23);
            this.bunifuLabel8.TabIndex = 21;
            this.bunifuLabel8.Text = "Pensja Brutto";
            this.bunifuLabel8.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel8.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // Add_Form_Pracownik
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.ClientSize = new System.Drawing.Size(595, 635);
            this.Controls.Add(this.bunifuLabel8);
            this.Controls.Add(this.bunifuLabel7);
            this.Controls.Add(this.bunifuLabel6);
            this.Controls.Add(this.bunifuLabel5);
            this.Controls.Add(this.bunifuLabel4);
            this.Controls.Add(this.bunifuLabel3);
            this.Controls.Add(this.bunifuLabel2);
            this.Controls.Add(this.bunifuLabel1);
            this.Controls.Add(this.Enter);
            this.Controls.Add(this.pensja_netto);
            this.Controls.Add(this.RodzajZat);
            this.Controls.Add(this.StudentNie);
            this.Controls.Add(this.StudentTak);
            this.Controls.Add(this.Stanow);
            this.Controls.Add(this.PlecK);
            this.Controls.Add(this.PlecM);
            this.Controls.Add(this.Pesel);
            this.Controls.Add(this.Naz);
            this.Controls.Add(this.Imie);
            this.Controls.Add(this.bunifuCheckBox2);
            this.Controls.Add(this.bunifuCheckbox1);
            this.Controls.Add(this.header);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Add_Form_Pracownik";
            this.Text = "Add_Form_Pracownik";
            this.header.ResumeLayout(false);
            this.header.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel header;
        private System.Windows.Forms.Label label1;
        private Bunifu.UI.WinForms.BunifuCheckBox bunifuCheckBox2;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox1;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox Naz;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox Imie;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl4;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox Pesel;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox pensja_netto;
        private System.Windows.Forms.ComboBox RodzajZat;
        private System.Windows.Forms.RadioButton StudentNie;
        private System.Windows.Forms.RadioButton StudentTak;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox Stanow;
        private System.Windows.Forms.RadioButton PlecK;
        private System.Windows.Forms.RadioButton PlecM;
        private Bunifu.Framework.UI.BunifuThinButton2 Enter;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel8;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel7;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel6;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel5;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuImageButton minimalize;
        private Bunifu.UI.WinForms.BunifuImageButton close;
    }
}