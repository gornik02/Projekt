﻿namespace home
{
    partial class Add_Form_Ksiegowa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Add_Form_Ksiegowa));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.header = new System.Windows.Forms.Panel();
            this.minimalize = new Bunifu.UI.WinForms.BunifuImageButton();
            this.close = new Bunifu.UI.WinForms.BunifuImageButton();
            this.label1 = new System.Windows.Forms.Label();
            this.Identyfikator = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.Imie = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.Nazwisko = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.Login = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.Haslo = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel5 = new Bunifu.UI.WinForms.BunifuLabel();
            this.Enter = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuDragControl3 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.header.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // header
            // 
            this.header.BackColor = System.Drawing.Color.White;
            this.header.Controls.Add(this.minimalize);
            this.header.Controls.Add(this.close);
            this.header.Controls.Add(this.label1);
            this.header.Dock = System.Windows.Forms.DockStyle.Top;
            this.header.Location = new System.Drawing.Point(0, 0);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(595, 93);
            this.header.TabIndex = 0;
            // 
            // minimalize
            // 
            this.minimalize.ActiveImage = null;
            this.minimalize.AllowAnimations = true;
            this.minimalize.AllowZooming = true;
            this.minimalize.BackColor = System.Drawing.Color.Transparent;
            this.minimalize.ErrorImage = ((System.Drawing.Image)(resources.GetObject("minimalize.ErrorImage")));
            this.minimalize.FadeWhenInactive = false;
            this.minimalize.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.minimalize.Image = ((System.Drawing.Image)(resources.GetObject("minimalize.Image")));
            this.minimalize.ImageActive = null;
            this.minimalize.ImageLocation = null;
            this.minimalize.ImageMargin = 0;
            this.minimalize.ImageSize = new System.Drawing.Size(37, 34);
            this.minimalize.ImageZoomSize = new System.Drawing.Size(37, 34);
            this.minimalize.InitialImage = ((System.Drawing.Image)(resources.GetObject("minimalize.InitialImage")));
            this.minimalize.Location = new System.Drawing.Point(481, 29);
            this.minimalize.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.minimalize.Name = "minimalize";
            this.minimalize.Rotation = 0;
            this.minimalize.ShowActiveImage = true;
            this.minimalize.ShowCursorChanges = true;
            this.minimalize.ShowImageBorders = false;
            this.minimalize.ShowSizeMarkers = false;
            this.minimalize.Size = new System.Drawing.Size(37, 34);
            this.minimalize.TabIndex = 11;
            this.minimalize.ToolTipText = "";
            this.minimalize.WaitOnLoad = false;
            this.minimalize.Zoom = 0;
            this.minimalize.ZoomSpeed = 10;
            this.minimalize.Click += new System.EventHandler(this.minimalize_Click);
            // 
            // close
            // 
            this.close.ActiveImage = null;
            this.close.AllowAnimations = true;
            this.close.AllowZooming = true;
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.ErrorImage = ((System.Drawing.Image)(resources.GetObject("close.ErrorImage")));
            this.close.FadeWhenInactive = false;
            this.close.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.close.Image = ((System.Drawing.Image)(resources.GetObject("close.Image")));
            this.close.ImageActive = null;
            this.close.ImageLocation = null;
            this.close.ImageMargin = 0;
            this.close.ImageSize = new System.Drawing.Size(37, 34);
            this.close.ImageZoomSize = new System.Drawing.Size(37, 34);
            this.close.InitialImage = ((System.Drawing.Image)(resources.GetObject("close.InitialImage")));
            this.close.Location = new System.Drawing.Point(526, 29);
            this.close.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.close.Name = "close";
            this.close.Rotation = 0;
            this.close.ShowActiveImage = true;
            this.close.ShowCursorChanges = true;
            this.close.ShowImageBorders = false;
            this.close.ShowSizeMarkers = false;
            this.close.Size = new System.Drawing.Size(37, 34);
            this.close.TabIndex = 10;
            this.close.ToolTipText = "";
            this.close.WaitOnLoad = false;
            this.close.Zoom = 0;
            this.close.ZoomSpeed = 10;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Book Antiqua", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(60, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 34);
            this.label1.TabIndex = 9;
            this.label1.Text = "Księgowy IO";
            // 
            // Identyfikator
            // 
            this.Identyfikator.AcceptsReturn = false;
            this.Identyfikator.AcceptsTab = false;
            this.Identyfikator.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Identyfikator.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Identyfikator.BackColor = System.Drawing.Color.Transparent;
            this.Identyfikator.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Identyfikator.BackgroundImage")));
            this.Identyfikator.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.Identyfikator.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Identyfikator.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.Identyfikator.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.Identyfikator.BorderRadius = 1;
            this.Identyfikator.BorderThickness = 2;
            this.Identyfikator.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Identyfikator.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Identyfikator.DefaultText = "";
            this.Identyfikator.FillColor = System.Drawing.Color.White;
            this.Identyfikator.HideSelection = true;
            this.Identyfikator.IconLeft = null;
            this.Identyfikator.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.Identyfikator.IconPadding = 10;
            this.Identyfikator.IconRight = null;
            this.Identyfikator.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.Identyfikator.Location = new System.Drawing.Point(267, 182);
            this.Identyfikator.MaxLength = 32767;
            this.Identyfikator.MinimumSize = new System.Drawing.Size(100, 35);
            this.Identyfikator.Modified = false;
            this.Identyfikator.Name = "Identyfikator";
            this.Identyfikator.PasswordChar = '\0';
            this.Identyfikator.ReadOnly = false;
            this.Identyfikator.SelectedText = "";
            this.Identyfikator.SelectionLength = 0;
            this.Identyfikator.SelectionStart = 0;
            this.Identyfikator.ShortcutsEnabled = true;
            this.Identyfikator.Size = new System.Drawing.Size(200, 35);
            this.Identyfikator.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.Identyfikator.TabIndex = 1;
            this.Identyfikator.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Identyfikator.TextMarginLeft = 5;
            this.Identyfikator.TextPlaceholder = "";
            this.Identyfikator.UseSystemPasswordChar = false;
            // 
            // Imie
            // 
            this.Imie.AcceptsReturn = false;
            this.Imie.AcceptsTab = false;
            this.Imie.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Imie.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Imie.BackColor = System.Drawing.Color.Transparent;
            this.Imie.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Imie.BackgroundImage")));
            this.Imie.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.Imie.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Imie.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.Imie.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.Imie.BorderRadius = 1;
            this.Imie.BorderThickness = 2;
            this.Imie.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Imie.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Imie.DefaultText = "";
            this.Imie.FillColor = System.Drawing.Color.White;
            this.Imie.HideSelection = true;
            this.Imie.IconLeft = null;
            this.Imie.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.Imie.IconPadding = 10;
            this.Imie.IconRight = null;
            this.Imie.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.Imie.Location = new System.Drawing.Point(267, 241);
            this.Imie.MaxLength = 32767;
            this.Imie.MinimumSize = new System.Drawing.Size(100, 35);
            this.Imie.Modified = false;
            this.Imie.Name = "Imie";
            this.Imie.PasswordChar = '\0';
            this.Imie.ReadOnly = false;
            this.Imie.SelectedText = "";
            this.Imie.SelectionLength = 0;
            this.Imie.SelectionStart = 0;
            this.Imie.ShortcutsEnabled = true;
            this.Imie.Size = new System.Drawing.Size(200, 35);
            this.Imie.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.Imie.TabIndex = 2;
            this.Imie.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Imie.TextMarginLeft = 5;
            this.Imie.TextPlaceholder = "";
            this.Imie.UseSystemPasswordChar = false;
            // 
            // Nazwisko
            // 
            this.Nazwisko.AcceptsReturn = false;
            this.Nazwisko.AcceptsTab = false;
            this.Nazwisko.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Nazwisko.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Nazwisko.BackColor = System.Drawing.Color.Transparent;
            this.Nazwisko.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Nazwisko.BackgroundImage")));
            this.Nazwisko.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.Nazwisko.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Nazwisko.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.Nazwisko.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.Nazwisko.BorderRadius = 1;
            this.Nazwisko.BorderThickness = 2;
            this.Nazwisko.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Nazwisko.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Nazwisko.DefaultText = "";
            this.Nazwisko.FillColor = System.Drawing.Color.White;
            this.Nazwisko.HideSelection = true;
            this.Nazwisko.IconLeft = null;
            this.Nazwisko.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.Nazwisko.IconPadding = 10;
            this.Nazwisko.IconRight = null;
            this.Nazwisko.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.Nazwisko.Location = new System.Drawing.Point(267, 299);
            this.Nazwisko.MaxLength = 32767;
            this.Nazwisko.MinimumSize = new System.Drawing.Size(100, 35);
            this.Nazwisko.Modified = false;
            this.Nazwisko.Name = "Nazwisko";
            this.Nazwisko.PasswordChar = '\0';
            this.Nazwisko.ReadOnly = false;
            this.Nazwisko.SelectedText = "";
            this.Nazwisko.SelectionLength = 0;
            this.Nazwisko.SelectionStart = 0;
            this.Nazwisko.ShortcutsEnabled = true;
            this.Nazwisko.Size = new System.Drawing.Size(200, 35);
            this.Nazwisko.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.Nazwisko.TabIndex = 3;
            this.Nazwisko.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Nazwisko.TextMarginLeft = 5;
            this.Nazwisko.TextPlaceholder = "";
            this.Nazwisko.UseSystemPasswordChar = false;
            // 
            // Login
            // 
            this.Login.AcceptsReturn = false;
            this.Login.AcceptsTab = false;
            this.Login.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Login.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Login.BackColor = System.Drawing.Color.Transparent;
            this.Login.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Login.BackgroundImage")));
            this.Login.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.Login.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Login.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.Login.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.Login.BorderRadius = 1;
            this.Login.BorderThickness = 2;
            this.Login.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Login.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Login.DefaultText = "";
            this.Login.FillColor = System.Drawing.Color.White;
            this.Login.HideSelection = true;
            this.Login.IconLeft = null;
            this.Login.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.Login.IconPadding = 10;
            this.Login.IconRight = null;
            this.Login.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.Login.Location = new System.Drawing.Point(267, 355);
            this.Login.MaxLength = 32767;
            this.Login.MinimumSize = new System.Drawing.Size(100, 35);
            this.Login.Modified = false;
            this.Login.Name = "Login";
            this.Login.PasswordChar = '\0';
            this.Login.ReadOnly = false;
            this.Login.SelectedText = "";
            this.Login.SelectionLength = 0;
            this.Login.SelectionStart = 0;
            this.Login.ShortcutsEnabled = true;
            this.Login.Size = new System.Drawing.Size(200, 35);
            this.Login.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.Login.TabIndex = 4;
            this.Login.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Login.TextMarginLeft = 5;
            this.Login.TextPlaceholder = "";
            this.Login.UseSystemPasswordChar = false;
            // 
            // Haslo
            // 
            this.Haslo.AcceptsReturn = false;
            this.Haslo.AcceptsTab = false;
            this.Haslo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Haslo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Haslo.BackColor = System.Drawing.Color.Transparent;
            this.Haslo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Haslo.BackgroundImage")));
            this.Haslo.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.Haslo.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Haslo.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.Haslo.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.Haslo.BorderRadius = 1;
            this.Haslo.BorderThickness = 2;
            this.Haslo.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Haslo.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Haslo.DefaultText = "";
            this.Haslo.FillColor = System.Drawing.Color.White;
            this.Haslo.HideSelection = true;
            this.Haslo.IconLeft = null;
            this.Haslo.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.Haslo.IconPadding = 10;
            this.Haslo.IconRight = null;
            this.Haslo.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.Haslo.Location = new System.Drawing.Point(267, 411);
            this.Haslo.MaxLength = 32767;
            this.Haslo.MinimumSize = new System.Drawing.Size(100, 35);
            this.Haslo.Modified = false;
            this.Haslo.Name = "Haslo";
            this.Haslo.PasswordChar = '\0';
            this.Haslo.ReadOnly = false;
            this.Haslo.SelectedText = "";
            this.Haslo.SelectionLength = 0;
            this.Haslo.SelectionStart = 0;
            this.Haslo.ShortcutsEnabled = true;
            this.Haslo.Size = new System.Drawing.Size(200, 35);
            this.Haslo.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.Haslo.TabIndex = 5;
            this.Haslo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Haslo.TextMarginLeft = 5;
            this.Haslo.TextPlaceholder = "";
            this.Haslo.UseSystemPasswordChar = false;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = null;
            this.bunifuLabel1.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel1.Location = new System.Drawing.Point(87, 182);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(174, 23);
            this.bunifuLabel1.TabIndex = 6;
            this.bunifuLabel1.Text = "Identyfikator firmowy";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = null;
            this.bunifuLabel2.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel2.Location = new System.Drawing.Point(224, 241);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(37, 23);
            this.bunifuLabel2.TabIndex = 7;
            this.bunifuLabel2.Text = "Imie";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.CursorType = null;
            this.bunifuLabel3.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel3.Location = new System.Drawing.Point(182, 299);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(79, 23);
            this.bunifuLabel3.TabIndex = 8;
            this.bunifuLabel3.Text = "Nazwisko";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.CursorType = null;
            this.bunifuLabel4.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel4.Location = new System.Drawing.Point(215, 355);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(46, 23);
            this.bunifuLabel4.TabIndex = 9;
            this.bunifuLabel4.Text = "Login";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel5
            // 
            this.bunifuLabel5.AutoEllipsis = false;
            this.bunifuLabel5.CursorType = null;
            this.bunifuLabel5.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.bunifuLabel5.Location = new System.Drawing.Point(213, 411);
            this.bunifuLabel5.Name = "bunifuLabel5";
            this.bunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel5.Size = new System.Drawing.Size(48, 23);
            this.bunifuLabel5.TabIndex = 10;
            this.bunifuLabel5.Text = "Haslo";
            this.bunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel5.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // Enter
            // 
            this.Enter.ActiveBorderThickness = 1;
            this.Enter.ActiveCornerRadius = 20;
            this.Enter.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.Enter.ActiveForecolor = System.Drawing.Color.White;
            this.Enter.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.Enter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.Enter.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Enter.BackgroundImage")));
            this.Enter.ButtonText = "Dodaj Osobę";
            this.Enter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Enter.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Enter.ForeColor = System.Drawing.Color.SeaGreen;
            this.Enter.IdleBorderThickness = 1;
            this.Enter.IdleCornerRadius = 20;
            this.Enter.IdleFillColor = System.Drawing.Color.SandyBrown;
            this.Enter.IdleForecolor = System.Drawing.Color.White;
            this.Enter.IdleLineColor = System.Drawing.Color.White;
            this.Enter.Location = new System.Drawing.Point(144, 491);
            this.Enter.Margin = new System.Windows.Forms.Padding(5);
            this.Enter.Name = "Enter";
            this.Enter.Size = new System.Drawing.Size(323, 55);
            this.Enter.TabIndex = 11;
            this.Enter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuDragControl3
            // 
            this.bunifuDragControl3.Fixed = true;
            this.bunifuDragControl3.Horizontal = true;
            this.bunifuDragControl3.TargetControl = this.header;
            this.bunifuDragControl3.Vertical = true;
            // 
            // Add_Form_Ksiegowa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.ClientSize = new System.Drawing.Size(595, 635);
            this.Controls.Add(this.Enter);
            this.Controls.Add(this.bunifuLabel5);
            this.Controls.Add(this.bunifuLabel4);
            this.Controls.Add(this.bunifuLabel3);
            this.Controls.Add(this.bunifuLabel2);
            this.Controls.Add(this.bunifuLabel1);
            this.Controls.Add(this.Haslo);
            this.Controls.Add(this.Login);
            this.Controls.Add(this.Nazwisko);
            this.Controls.Add(this.Imie);
            this.Controls.Add(this.Identyfikator);
            this.Controls.Add(this.header);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Add_Form_Ksiegowa";
            this.Text = "Add_Form_Ksiegowa";
            this.header.ResumeLayout(false);
            this.header.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel header;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel5;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox Haslo;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox Login;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox Nazwisko;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox Imie;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox Identyfikator;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuThinButton2 Enter;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl3;
        private Bunifu.UI.WinForms.BunifuImageButton minimalize;
        private Bunifu.UI.WinForms.BunifuImageButton close;
    }
}