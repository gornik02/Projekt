﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace home
{
    public partial class Home : Form
    {
        static Home _obj;

        public static Home Instance
        {
            get
            {
                if (_obj == null)
                {
                    _obj = new Home();
                }
                return _obj;
            }
        }

        public Panel PnlContainer
        {
            get { return container; }
            set { container = value; }
        }

        public Bunifu.Framework.UI.BunifuFlatButton but1
        {
            get { return b1; }
            set { b1 = value; }
        }

        public Bunifu.Framework.UI.BunifuFlatButton but2
        {
            get { return b2; }
            set { b2 = value; }
        }

        public Bunifu.Framework.UI.BunifuFlatButton but3
        {
            get { return b3; }
            set { b3 = value; }
        }

        public Bunifu.Framework.UI.BunifuFlatButton but4
        {
            get { return b4; }
            set { b4 = value; }
        }

        public Home()
        {
            InitializeComponent();
        }

        private void Home_Load(object sender, EventArgs e)
        {
            _obj = this;

            polaczeniezbaza pzb = new polaczeniezbaza();
            pzb.Dock = DockStyle.Fill;
            container.Controls.Add(pzb);
        }

        private void b1_Click(object sender, EventArgs e)
        {
            container.Controls["polaczeniezbaza"].BringToFront();
        }

        private void b2_Click(object sender, EventArgs e)
        {
            if (!Home.Instance.container.Controls.ContainsKey("Widok_bazodanowy"))
            {
                Widok_bazodanowy wb = new Widok_bazodanowy();
                wb.Dock = DockStyle.Fill;
                Home.Instance.container.Controls.Add(wb);
            }
            Home.Instance.container.Controls["Widok_bazodanowy"].BringToFront();
        }

        private void b3_Click(object sender, EventArgs e)
        {
            if (!Home.Instance.container.Controls.ContainsKey("DELETE"))
            {
                /*to są dane */
                DELETE dane = new DELETE();
                dane.Dock = DockStyle.Fill;
                Home.Instance.container.Controls.Add(dane);
            }
            Home.Instance.container.Controls["DELETE"].BringToFront();
        }

        private void b4_Click(object sender, EventArgs e)
        {
            if (!Home.Instance.container.Controls.ContainsKey("Konta_Ksiegowych"))
            {
                Konta_Ksiegowych kk = new Konta_Ksiegowych();
                kk.Dock = DockStyle.Fill;
                Home.Instance.container.Controls.Add(kk);
            }
            Home.Instance.container.Controls["Konta_Ksiegowych"].BringToFront();
        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void minimalize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
