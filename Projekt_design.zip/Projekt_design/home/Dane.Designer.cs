﻿namespace home
{
    partial class DELETE
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DELETE));
            this.listView1 = new System.Windows.Forms.ListView();
            this.chID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chImie = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chNazwisko = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chPesel = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chPlec = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chStanowisko = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chCzy_Student = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chRodzajZatrudnienia = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chPensja_Brutto = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.UPDATE = new Bunifu.Framework.UI.BunifuThinButton2();
            this.ADD = new Bunifu.Framework.UI.BunifuThinButton2();
            this.Usuntemp_1 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.USUN_2 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chID,
            this.chImie,
            this.chNazwisko,
            this.chPesel,
            this.chPlec,
            this.chStanowisko,
            this.chCzy_Student,
            this.chRodzajZatrudnienia,
            this.chPensja_Brutto});
            this.listView1.FullRowSelect = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(4, 4);
            this.listView1.Margin = new System.Windows.Forms.Padding(4);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(846, 450);
            this.listView1.TabIndex = 3;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // chID
            // 
            this.chID.Text = "ID";
            this.chID.Width = 35;
            // 
            // chImie
            // 
            this.chImie.Text = "Imię";
            this.chImie.Width = 90;
            // 
            // chNazwisko
            // 
            this.chNazwisko.Text = "Nazwisko";
            this.chNazwisko.Width = 90;
            // 
            // chPesel
            // 
            this.chPesel.Text = "Numer PESEL";
            this.chPesel.Width = 100;
            // 
            // chPlec
            // 
            this.chPlec.Text = "Płeć";
            this.chPlec.Width = 80;
            // 
            // chStanowisko
            // 
            this.chStanowisko.Text = "Stanowisko";
            this.chStanowisko.Width = 102;
            // 
            // chCzy_Student
            // 
            this.chCzy_Student.Text = "Czy Student";
            this.chCzy_Student.Width = 93;
            // 
            // chRodzajZatrudnienia
            // 
            this.chRodzajZatrudnienia.Text = "Rodzaj Zatrudnienia";
            this.chRodzajZatrudnienia.Width = 135;
            // 
            // chPensja_Brutto
            // 
            this.chPensja_Brutto.Text = "Pensja Brutto [zł]";
            this.chPensja_Brutto.Width = 95;
            // 
            // UPDATE
            // 
            this.UPDATE.ActiveBorderThickness = 1;
            this.UPDATE.ActiveCornerRadius = 20;
            this.UPDATE.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.UPDATE.ActiveForecolor = System.Drawing.Color.White;
            this.UPDATE.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.UPDATE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.UPDATE.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("UPDATE.BackgroundImage")));
            this.UPDATE.ButtonText = "Odśwież";
            this.UPDATE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UPDATE.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UPDATE.ForeColor = System.Drawing.Color.SeaGreen;
            this.UPDATE.IdleBorderThickness = 1;
            this.UPDATE.IdleCornerRadius = 20;
            this.UPDATE.IdleFillColor = System.Drawing.Color.SandyBrown;
            this.UPDATE.IdleForecolor = System.Drawing.Color.White;
            this.UPDATE.IdleLineColor = System.Drawing.Color.White;
            this.UPDATE.Location = new System.Drawing.Point(20, 463);
            this.UPDATE.Margin = new System.Windows.Forms.Padding(5);
            this.UPDATE.Name = "UPDATE";
            this.UPDATE.Size = new System.Drawing.Size(175, 48);
            this.UPDATE.TabIndex = 12;
            this.UPDATE.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ADD
            // 
            this.ADD.ActiveBorderThickness = 1;
            this.ADD.ActiveCornerRadius = 20;
            this.ADD.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.ADD.ActiveForecolor = System.Drawing.Color.White;
            this.ADD.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.ADD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.ADD.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ADD.BackgroundImage")));
            this.ADD.ButtonText = "Dodaj";
            this.ADD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ADD.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ADD.ForeColor = System.Drawing.Color.SeaGreen;
            this.ADD.IdleBorderThickness = 1;
            this.ADD.IdleCornerRadius = 20;
            this.ADD.IdleFillColor = System.Drawing.Color.SandyBrown;
            this.ADD.IdleForecolor = System.Drawing.Color.White;
            this.ADD.IdleLineColor = System.Drawing.Color.White;
            this.ADD.Location = new System.Drawing.Point(228, 463);
            this.ADD.Margin = new System.Windows.Forms.Padding(5);
            this.ADD.Name = "ADD";
            this.ADD.Size = new System.Drawing.Size(175, 48);
            this.ADD.TabIndex = 13;
            this.ADD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Usuntemp_1
            // 
            this.Usuntemp_1.ActiveBorderThickness = 1;
            this.Usuntemp_1.ActiveCornerRadius = 20;
            this.Usuntemp_1.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.Usuntemp_1.ActiveForecolor = System.Drawing.Color.White;
            this.Usuntemp_1.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.Usuntemp_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.Usuntemp_1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Usuntemp_1.BackgroundImage")));
            this.Usuntemp_1.ButtonText = "Tryb usuwania";
            this.Usuntemp_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Usuntemp_1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Usuntemp_1.ForeColor = System.Drawing.Color.SeaGreen;
            this.Usuntemp_1.IdleBorderThickness = 1;
            this.Usuntemp_1.IdleCornerRadius = 20;
            this.Usuntemp_1.IdleFillColor = System.Drawing.Color.SandyBrown;
            this.Usuntemp_1.IdleForecolor = System.Drawing.Color.White;
            this.Usuntemp_1.IdleLineColor = System.Drawing.Color.White;
            this.Usuntemp_1.Location = new System.Drawing.Point(444, 463);
            this.Usuntemp_1.Margin = new System.Windows.Forms.Padding(5);
            this.Usuntemp_1.Name = "Usuntemp_1";
            this.Usuntemp_1.Size = new System.Drawing.Size(175, 48);
            this.Usuntemp_1.TabIndex = 14;
            this.Usuntemp_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // USUN_2
            // 
            this.USUN_2.ActiveBorderThickness = 1;
            this.USUN_2.ActiveCornerRadius = 20;
            this.USUN_2.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.USUN_2.ActiveForecolor = System.Drawing.Color.White;
            this.USUN_2.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(154)))), ((int)(((byte)(86)))));
            this.USUN_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.USUN_2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("USUN_2.BackgroundImage")));
            this.USUN_2.ButtonText = "Usuń";
            this.USUN_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.USUN_2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.USUN_2.ForeColor = System.Drawing.Color.SeaGreen;
            this.USUN_2.IdleBorderThickness = 1;
            this.USUN_2.IdleCornerRadius = 20;
            this.USUN_2.IdleFillColor = System.Drawing.Color.SandyBrown;
            this.USUN_2.IdleForecolor = System.Drawing.Color.White;
            this.USUN_2.IdleLineColor = System.Drawing.Color.White;
            this.USUN_2.Location = new System.Drawing.Point(653, 463);
            this.USUN_2.Margin = new System.Windows.Forms.Padding(5);
            this.USUN_2.Name = "USUN_2";
            this.USUN_2.Size = new System.Drawing.Size(175, 48);
            this.USUN_2.TabIndex = 15;
            this.USUN_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DELETE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(184)))), ((int)(((byte)(184)))));
            this.Controls.Add(this.USUN_2);
            this.Controls.Add(this.Usuntemp_1);
            this.Controls.Add(this.ADD);
            this.Controls.Add(this.UPDATE);
            this.Controls.Add(this.listView1);
            this.Name = "DELETE";
            this.Size = new System.Drawing.Size(854, 532);
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader chID;
        private System.Windows.Forms.ColumnHeader chImie;
        private System.Windows.Forms.ColumnHeader chNazwisko;
        private System.Windows.Forms.ColumnHeader chPesel;
        private System.Windows.Forms.ColumnHeader chPlec;
        private System.Windows.Forms.ColumnHeader chStanowisko;
        private System.Windows.Forms.ColumnHeader chCzy_Student;
        private System.Windows.Forms.ColumnHeader chRodzajZatrudnienia;
        private System.Windows.Forms.ColumnHeader chPensja_Brutto;
        private Bunifu.Framework.UI.BunifuThinButton2 UPDATE;
        private Bunifu.Framework.UI.BunifuThinButton2 ADD;
        private Bunifu.Framework.UI.BunifuThinButton2 Usuntemp_1;
        private Bunifu.Framework.UI.BunifuThinButton2 USUN_2;
    }
}
