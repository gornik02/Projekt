﻿namespace Projekt
{


    public partial class Database_PracownicyDataSet
    {
    }
}
