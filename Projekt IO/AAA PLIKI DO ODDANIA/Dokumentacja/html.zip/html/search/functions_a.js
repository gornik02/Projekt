var searchData=
[
  ['set',['Set',['../class_projekt_1_1_wynagrodzenia.html#a72770439172dc9e89a56504b32462a24',1,'Projekt::Wynagrodzenia']]],
  ['set2',['Set2',['../class_projekt_1_1_wynagrodzenia.html#af1961ce3239ad4cbf7e97199fd2947b7',1,'Projekt::Wynagrodzenia']]]
];
