var searchData=
[
  ['typzwolnienia',['typZwolnienia',['../class_projekt_1_1_zwolnienia.html#a2bdd18db20bfcd5e521d0f4ab3a0d833',1,'Projekt::Zwolnienia']]]
];
