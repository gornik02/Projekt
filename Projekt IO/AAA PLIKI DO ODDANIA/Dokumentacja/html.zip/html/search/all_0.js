var searchData=
[
  ['_5fconnectiondata',['_connectionData',['../class_projekt_1_1_data_base_connection.html#a0470f7accbf63cd4e87abb2a55c0d581',1,'Projekt.DataBaseConnection._connectionData()'],['../class_projekt_1_1_data_base_connection.html#ae0a58cc0a704709db70d4fb01d287a3e',1,'Projekt.DataBaseConnection._ConnectionData()']]]
];
