var searchData=
[
  ['add_5fperson',['Add_Person',['../class_projekt_1_1_data_base_connection.html#a5a6666992caccae98cd06e9f935b5db1',1,'Projekt::DataBaseConnection']]],
  ['add_5fperson2',['Add_Person2',['../class_projekt_1_1_data_base_connection.html#a92e8da76321783abca251438bf75a8b4',1,'Projekt::DataBaseConnection']]],
  ['autoclosingmessagebox',['AutoClosingMessageBox',['../class_projekt_1_1_main___form_1_1_auto_closing_message_box.html',1,'Projekt::Main_Form']]]
];
