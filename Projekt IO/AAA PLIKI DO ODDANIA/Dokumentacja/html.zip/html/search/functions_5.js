var searchData=
[
  ['ksiegowi',['Ksiegowi',['../class_projekt_1_1_ksiegowi.html#aa02bf0a3deb87a192ec51068a186acb2',1,'Projekt::Ksiegowi']]]
];
