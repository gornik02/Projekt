var searchData=
[
  ['zwolnienia',['Zwolnienia',['../class_projekt_1_1_zwolnienia.html',1,'Projekt']]],
  ['zwolnienia_5fw_5fdanym_5fmiesiacu',['ZWOLNIENIA_W_DANYM_MIESIACU',['../class_projekt_1_1_wynagrodzenia.html#ae8ad36dc4137e717b207f91fc0a468f4',1,'Projekt::Wynagrodzenia']]],
  ['zwolnieniedo',['ZwolnienieDo',['../class_projekt_1_1_zwolnienia.html#ab368f35ec5afac14545e7b2b7f5ddc14',1,'Projekt::Zwolnienia']]],
  ['zwolnienieod',['ZwolnienieOd',['../class_projekt_1_1_zwolnienia.html#ab4ac6cbf514bb680e7957e6f30cfea58',1,'Projekt::Zwolnienia']]]
];
