var searchData=
[
  ['updateorderoption',['UpdateOrderOption',['../class_projekt_1_1_database___pracownicy_data_set_table_adapters_1_1_table_adapter_manager.html#aecba9a3624f9186b7113ad03af862e0d',1,'Projekt::Database_PracownicyDataSetTableAdapters::TableAdapterManager']]]
];
