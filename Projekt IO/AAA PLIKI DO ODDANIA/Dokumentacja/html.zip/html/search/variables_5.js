var searchData=
[
  ['miesiac',['miesiac',['../class_projekt_1_1_wynagrodzenia.html#add46cc8d96f3f77d9b469ad107298dd2',1,'Projekt::Wynagrodzenia']]]
];
