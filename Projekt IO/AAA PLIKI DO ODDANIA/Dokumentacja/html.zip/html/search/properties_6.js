var searchData=
[
  ['pensja_5fbrutto',['PENSJA_BRUTTO',['../class_projekt_1_1_persons.html#a6e600f42d4b5c8419a311c877d12e46e',1,'Projekt.Persons.PENSJA_BRUTTO()'],['../class_projekt_1_1_wynagrodzenia.html#ae3d3716b198f5a734b0af9b14374dec4',1,'Projekt.Wynagrodzenia.PENSJA_BRUTTO()']]],
  ['pensja_5fbrutto_5fbrutto',['PENSJA_BRUTTO_BRUTTO',['../class_projekt_1_1_wynagrodzenia.html#a1cb8640ba71b338344d072ed2ab479f2',1,'Projekt::Wynagrodzenia']]],
  ['pensja_5fnetto',['PENSJA_NETTO',['../class_projekt_1_1_wynagrodzenia.html#a63db74567033b9a27dcd3a79e30d426d',1,'Projekt::Wynagrodzenia']]],
  ['pesel',['PESEL',['../class_projekt_1_1_persons.html#a4a668e9f5045cf9a2b88a8d672beed8e',1,'Projekt.Persons.PESEL()'],['../class_projekt_1_1_zwolnienia.html#ab668c1cd6cc195cbad50c6ceae043e11',1,'Projekt.Zwolnienia.pesel()']]],
  ['plec',['PLEC',['../class_projekt_1_1_persons.html#a6f8d87ae074bbf69b205c63e9ae807d9',1,'Projekt::Persons']]]
];
