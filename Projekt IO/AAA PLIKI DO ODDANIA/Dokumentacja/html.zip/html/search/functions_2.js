var searchData=
[
  ['databaseconnection',['DataBaseConnection',['../class_projekt_1_1_data_base_connection.html#a57cf48fb438860d07c150d7c1b70b7fb',1,'Projekt::DataBaseConnection']]],
  ['delete_5fperson',['Delete_Person',['../class_projekt_1_1_data_base_connection.html#af05ce3a06c90af85117b41ea8be8ba13',1,'Projekt::DataBaseConnection']]],
  ['delete_5fperson2',['Delete_Person2',['../class_projekt_1_1_data_base_connection.html#a0f6ae39509c0ec3b1f366924a2176bc8',1,'Projekt::DataBaseConnection']]],
  ['dispose',['Dispose',['../class_projekt_1_1_form4.html#af90b7f0e74afceab53407a516b9cec94',1,'Projekt.Form4.Dispose()'],['../class_projekt_1_1_form3.html#ada69743bee8b59237e174e33238fdfbc',1,'Projekt.Form3.Dispose()'],['../class_projekt_1_1_main___form.html#a35eeba28fe22e60855dd8c77dd29ab55',1,'Projekt.Main_Form.Dispose()'],['../class_projekt_1_1_logowanie.html#a8fc5beca436046e668241eb1eb833617',1,'Projekt.Logowanie.Dispose()'],['../class_projekt_1_1_form2.html#a7ddfa1aed3b6ce0f00cac4a22f16bad5',1,'Projekt.Form2.Dispose()']]]
];
