var searchData=
[
  ['tableadaptermanager',['TableAdapterManager',['../class_projekt_1_1_database___pracownicy_data_set_table_adapters_1_1_table_adapter_manager.html',1,'Projekt::Database_PracownicyDataSetTableAdapters']]],
  ['tostring',['ToString',['../class_projekt_1_1_ksiegowi.html#aaba4aa23487c04f5952ddbd2adfcfd97',1,'Projekt.Ksiegowi.ToString()'],['../class_projekt_1_1_persons.html#af6474fc5c8936c987c0c6c7057489a0f',1,'Projekt.Persons.ToString()']]],
  ['typzwolnienia',['typZwolnienia',['../class_projekt_1_1_zwolnienia.html#a2bdd18db20bfcd5e521d0f4ab3a0d833',1,'Projekt::Zwolnienia']]]
];
