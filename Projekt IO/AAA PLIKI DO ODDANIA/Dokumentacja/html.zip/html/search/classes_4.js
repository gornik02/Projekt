var searchData=
[
  ['logowanie',['Logowanie',['../class_projekt_1_1_logowanie.html',1,'Projekt']]]
];
