var searchData=
[
  ['change_5findex_5fwhen_5fdeleted',['Change_Index_When_Deleted',['../class_projekt_1_1_data_base_connection.html#a3f9be881ef2811a33e09b5a4c6b784d7',1,'Projekt::DataBaseConnection']]],
  ['closeconnection',['CloseConnection',['../class_projekt_1_1_data_base_connection.html#af7f74d11139bc2cea86f1f102664314b',1,'Projekt::DataBaseConnection']]]
];
