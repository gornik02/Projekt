var searchData=
[
  ['wynagrodzenia',['Wynagrodzenia',['../class_projekt_1_1_wynagrodzenia.html',1,'Projekt']]]
];
