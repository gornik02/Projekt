var searchData=
[
  ['server_5fname',['server_name',['../class_projekt_1_1_data_base_connection.html#ae4991908eeb8fa9d0e6ec63e4aa39095',1,'Projekt::DataBaseConnection']]]
];
