var searchData=
[
  ['id',['ID',['../class_projekt_1_1_ksiegowi.html#a001bd6702215a1082cafda127a7a8ee5',1,'Projekt.Ksiegowi.ID()'],['../class_projekt_1_1_zwolnienia.html#a24ff89e3e9f0d448f4120c55b476dc4e',1,'Projekt.Zwolnienia.id()']]],
  ['id_5ffirmowy',['ID_Firmowy',['../class_projekt_1_1_ksiegowi.html#a99f12963bc34607a329d5781b81e4843',1,'Projekt::Ksiegowi']]],
  ['imie',['IMIE',['../class_projekt_1_1_ksiegowi.html#a3df0155338777fd8aba7d22f04fe4f08',1,'Projekt.Ksiegowi.IMIE()'],['../class_projekt_1_1_persons.html#ae59f2ea1178dc849563eee7cf6e2b90f',1,'Projekt.Persons.IMIE()']]]
];
