var searchData=
[
  ['resourcemanager',['ResourceManager',['../class_projekt_1_1_properties_1_1_resources.html#afb0559246c61b852da41b82dd56dc40c',1,'Projekt::Properties::Resources']]],
  ['rodzaj_5fzatrudnienia',['RODZAJ_ZATRUDNIENIA',['../class_projekt_1_1_persons.html#a03f412aebf23364f86885e6cb28824f2',1,'Projekt::Persons']]]
];
