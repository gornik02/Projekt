var searchData=
[
  ['selfreferencecomparer',['SelfReferenceComparer',['../class_projekt_1_1_database___pracownicy_data_set_table_adapters_1_1_table_adapter_manager_1_1_self_reference_comparer.html',1,'Projekt::Database_PracownicyDataSetTableAdapters::TableAdapterManager']]],
  ['settings',['Settings',['../class_projekt_1_1_properties_1_1_settings.html',1,'Projekt::Properties']]],
  ['sqlconnectionstringbuilder',['SqlConnectionStringBuilder',['../class_projekt_1_1_sql_connection_string_builder.html',1,'Projekt']]]
];
