var searchData=
[
  ['openconnection',['OpenConnection',['../class_projekt_1_1_data_base_connection.html#a6049e3994650d647bedaeae3ff27b1ad',1,'Projekt::DataBaseConnection']]]
];
