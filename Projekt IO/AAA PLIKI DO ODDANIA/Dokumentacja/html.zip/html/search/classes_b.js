var searchData=
[
  ['zwolnienia',['Zwolnienia',['../class_projekt_1_1_zwolnienia.html',1,'Projekt']]]
];
