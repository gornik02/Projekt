var searchData=
[
  ['database_5fname',['database_name',['../class_projekt_1_1_data_base_connection.html#a5e1804ac0813f668212084728ad17732',1,'Projekt::DataBaseConnection']]]
];
