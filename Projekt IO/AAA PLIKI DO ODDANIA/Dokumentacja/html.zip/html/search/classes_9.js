var searchData=
[
  ['tableadaptermanager',['TableAdapterManager',['../class_projekt_1_1_database___pracownicy_data_set_table_adapters_1_1_table_adapter_manager.html',1,'Projekt::Database_PracownicyDataSetTableAdapters']]]
];
