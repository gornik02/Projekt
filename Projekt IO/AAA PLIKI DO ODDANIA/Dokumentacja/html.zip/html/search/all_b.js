var searchData=
[
  ['nazwisko',['NAZWISKO',['../class_projekt_1_1_ksiegowi.html#af502513d1af40a82bc3fe6cb44967ee9',1,'Projekt.Ksiegowi.NAZWISKO()'],['../class_projekt_1_1_persons.html#ab12201157beeef59b94b3709a7bc9859',1,'Projekt.Persons.NAZWISKO()']]],
  ['nip',['nip',['../class_projekt_1_1_zwolnienia.html#a4ec8afb3ae790fd8139503d86d6d4be0',1,'Projekt::Zwolnienia']]]
];
