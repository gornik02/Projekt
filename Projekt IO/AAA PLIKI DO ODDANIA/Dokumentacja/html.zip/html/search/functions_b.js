var searchData=
[
  ['tostring',['ToString',['../class_projekt_1_1_ksiegowi.html#aaba4aa23487c04f5952ddbd2adfcfd97',1,'Projekt.Ksiegowi.ToString()'],['../class_projekt_1_1_persons.html#af6474fc5c8936c987c0c6c7057489a0f',1,'Projekt.Persons.ToString()']]]
];
