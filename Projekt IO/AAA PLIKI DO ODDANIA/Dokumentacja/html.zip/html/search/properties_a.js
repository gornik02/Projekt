var searchData=
[
  ['zwolnieniedo',['ZwolnienieDo',['../class_projekt_1_1_zwolnienia.html#ab368f35ec5afac14545e7b2b7f5ddc14',1,'Projekt::Zwolnienia']]],
  ['zwolnienieod',['ZwolnienieOd',['../class_projekt_1_1_zwolnienia.html#ab4ac6cbf514bb680e7957e6f30cfea58',1,'Projekt::Zwolnienia']]]
];
