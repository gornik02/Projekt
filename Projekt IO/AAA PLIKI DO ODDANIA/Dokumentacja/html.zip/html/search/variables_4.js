var searchData=
[
  ['ilosc_5fdni_5fmiesiac',['ILOSC_DNI_MIESIAC',['../class_projekt_1_1_wynagrodzenia.html#a05848c7c40dce7535c80048c0730e46f',1,'Projekt::Wynagrodzenia']]],
  ['ilosc_5fdni_5fprzepracowane',['ILOSC_DNI_PRZEPRACOWANE',['../class_projekt_1_1_wynagrodzenia.html#a85d747317060e61844349f2f4f68ecc7',1,'Projekt::Wynagrodzenia']]]
];
