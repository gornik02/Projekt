var searchData=
[
  ['_5fconnectiondata',['_connectionData',['../class_projekt_1_1_data_base_connection.html#a0470f7accbf63cd4e87abb2a55c0d581',1,'Projekt::DataBaseConnection']]]
];
