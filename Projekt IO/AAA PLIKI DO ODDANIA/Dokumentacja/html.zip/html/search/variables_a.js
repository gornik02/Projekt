var searchData=
[
  ['zwolnienia_5fw_5fdanym_5fmiesiacu',['ZWOLNIENIA_W_DANYM_MIESIACU',['../class_projekt_1_1_wynagrodzenia.html#ae8ad36dc4137e717b207f91fc0a468f4',1,'Projekt::Wynagrodzenia']]]
];
