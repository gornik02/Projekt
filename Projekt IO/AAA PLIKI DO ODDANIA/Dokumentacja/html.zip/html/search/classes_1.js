var searchData=
[
  ['database_5fpracownicydataset',['Database_PracownicyDataSet',['../class_projekt_1_1_database___pracownicy_data_set.html',1,'Projekt']]],
  ['databaseconnection',['DataBaseConnection',['../class_projekt_1_1_data_base_connection.html',1,'Projekt']]]
];
