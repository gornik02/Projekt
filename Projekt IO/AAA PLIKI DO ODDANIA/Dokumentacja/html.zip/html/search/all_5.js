var searchData=
[
  ['g',['G',['../class_projekt_1_1_wynagrodzenia.html#ae9ea5f09ff833eb8a0a4cc2fcf9c5469',1,'Projekt::Wynagrodzenia']]],
  ['getrealupdatedrows',['GetRealUpdatedRows',['../class_projekt_1_1_database___pracownicy_data_set_table_adapters_1_1_table_adapter_manager.html#a2579628608402c61ea5bb35bb186acec',1,'Projekt::Database_PracownicyDataSetTableAdapters::TableAdapterManager']]]
];
