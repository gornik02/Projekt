var searchData=
[
  ['id',['ID',['../class_projekt_1_1_ksiegowi.html#a001bd6702215a1082cafda127a7a8ee5',1,'Projekt.Ksiegowi.ID()'],['../class_projekt_1_1_zwolnienia.html#a24ff89e3e9f0d448f4120c55b476dc4e',1,'Projekt.Zwolnienia.id()']]],
  ['id_5ffirmowy',['ID_Firmowy',['../class_projekt_1_1_ksiegowi.html#a99f12963bc34607a329d5781b81e4843',1,'Projekt::Ksiegowi']]],
  ['ilosc_5fdni_5fmiesiac',['ILOSC_DNI_MIESIAC',['../class_projekt_1_1_wynagrodzenia.html#a05848c7c40dce7535c80048c0730e46f',1,'Projekt::Wynagrodzenia']]],
  ['ilosc_5fdni_5fprzepracowane',['ILOSC_DNI_PRZEPRACOWANE',['../class_projekt_1_1_wynagrodzenia.html#a85d747317060e61844349f2f4f68ecc7',1,'Projekt::Wynagrodzenia']]],
  ['iloscdniurlop',['iloscDniUrlop',['../class_projekt_1_1_wynagrodzenia.html#a24f48baf1a9d89e0d3df33059f0ac09f',1,'Projekt::Wynagrodzenia']]],
  ['imie',['IMIE',['../class_projekt_1_1_ksiegowi.html#a3df0155338777fd8aba7d22f04fe4f08',1,'Projekt.Ksiegowi.IMIE()'],['../class_projekt_1_1_persons.html#ae59f2ea1178dc849563eee7cf6e2b90f',1,'Projekt.Persons.IMIE()']]],
  ['initializecomponent',['InitializeComponent',['../class_projekt_1_1_form4.html#a86da7fd4f2bf28051a256c219db7052d',1,'Projekt.Form4.InitializeComponent()'],['../class_projekt_1_1_form3.html#aec8c8c545d7e2c4a83aaf6b02ba31a4d',1,'Projekt.Form3.InitializeComponent()'],['../class_projekt_1_1_main___form.html#a4a682a32ccc8b512218b1465c0788307',1,'Projekt.Main_Form.InitializeComponent()'],['../class_projekt_1_1_logowanie.html#a38a08a71ea6626617c6bc253e2f523cb',1,'Projekt.Logowanie.InitializeComponent()'],['../class_projekt_1_1_form2.html#a7ff59eccd59ce2ef3cdf2dedc9f79cb2',1,'Projekt.Form2.InitializeComponent()']]]
];
