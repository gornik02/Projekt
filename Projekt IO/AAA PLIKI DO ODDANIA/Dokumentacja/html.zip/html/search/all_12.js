var searchData=
[
  ['wynagrodzenia',['Wynagrodzenia',['../class_projekt_1_1_wynagrodzenia.html',1,'Projekt.Wynagrodzenia'],['../class_projekt_1_1_wynagrodzenia.html#aff5789fa0e6bd2d11c3bb8905856fe4b',1,'Projekt.Wynagrodzenia.Wynagrodzenia(Persons OSOBA, int ILOSC_DNI_MIESIAC, List&lt; Zwolnienia &gt; ZWOLNIENIA_W_DANYM_MIESIACU, int miesiac)'],['../class_projekt_1_1_wynagrodzenia.html#ab6af0e8f41c08b2af6b05110a3da2c87',1,'Projekt.Wynagrodzenia.Wynagrodzenia(Persons OSOBA, int ILOSC_DNI_MIESIAC, int miesiac)']]],
  ['wynagrodzenie_5fzasadnicze',['WYNAGRODZENIE_ZASADNICZE',['../class_projekt_1_1_wynagrodzenia.html#a7782445a25f6ae380f4a585d7db0319b',1,'Projekt::Wynagrodzenia']]]
];
