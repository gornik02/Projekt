var searchData=
[
  ['wynagrodzenie_5fzasadnicze',['WYNAGRODZENIE_ZASADNICZE',['../class_projekt_1_1_wynagrodzenia.html#a7782445a25f6ae380f4a585d7db0319b',1,'Projekt::Wynagrodzenia']]]
];
