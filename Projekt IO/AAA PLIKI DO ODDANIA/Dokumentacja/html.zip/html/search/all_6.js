var searchData=
[
  ['haslo',['HASLO',['../class_projekt_1_1_ksiegowi.html#af763bef44c141fa9da592b249a303f3e',1,'Projekt::Ksiegowi']]]
];
