var searchData=
[
  ['updateall',['UpdateAll',['../class_projekt_1_1_database___pracownicy_data_set_table_adapters_1_1_table_adapter_manager.html#ab900ab7fa21976a9dcf5eb1f5ca32aa1',1,'Projekt::Database_PracownicyDataSetTableAdapters::TableAdapterManager']]],
  ['updatedeletedrows',['UpdateDeletedRows',['../class_projekt_1_1_database___pracownicy_data_set_table_adapters_1_1_table_adapter_manager.html#aaa2c419e74454a43e04cf176bbea7518',1,'Projekt::Database_PracownicyDataSetTableAdapters::TableAdapterManager']]],
  ['updateinsertedrows',['UpdateInsertedRows',['../class_projekt_1_1_database___pracownicy_data_set_table_adapters_1_1_table_adapter_manager.html#aab06b10b1d84c311e99e36c9ff9e0355',1,'Projekt::Database_PracownicyDataSetTableAdapters::TableAdapterManager']]],
  ['updateupdatedrows',['UpdateUpdatedRows',['../class_projekt_1_1_database___pracownicy_data_set_table_adapters_1_1_table_adapter_manager.html#a6794d649a7d1c44de2cbfd1ab662d5c7',1,'Projekt::Database_PracownicyDataSetTableAdapters::TableAdapterManager']]]
];
