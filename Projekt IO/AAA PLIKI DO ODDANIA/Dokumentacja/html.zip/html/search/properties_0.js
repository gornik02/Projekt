var searchData=
[
  ['_5fconnectiondata',['_ConnectionData',['../class_projekt_1_1_data_base_connection.html#ae0a58cc0a704709db70d4fb01d287a3e',1,'Projekt::DataBaseConnection']]]
];
