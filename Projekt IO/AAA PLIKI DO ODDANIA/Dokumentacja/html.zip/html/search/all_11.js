var searchData=
[
  ['u',['U',['../class_projekt_1_1_wynagrodzenia.html#a167a4844103945bfea1b5bb4defdded3',1,'Projekt::Wynagrodzenia']]],
  ['updateall',['UpdateAll',['../class_projekt_1_1_database___pracownicy_data_set_table_adapters_1_1_table_adapter_manager.html#ab900ab7fa21976a9dcf5eb1f5ca32aa1',1,'Projekt::Database_PracownicyDataSetTableAdapters::TableAdapterManager']]],
  ['updatedeletedrows',['UpdateDeletedRows',['../class_projekt_1_1_database___pracownicy_data_set_table_adapters_1_1_table_adapter_manager.html#aaa2c419e74454a43e04cf176bbea7518',1,'Projekt::Database_PracownicyDataSetTableAdapters::TableAdapterManager']]],
  ['updateinsertedrows',['UpdateInsertedRows',['../class_projekt_1_1_database___pracownicy_data_set_table_adapters_1_1_table_adapter_manager.html#aab06b10b1d84c311e99e36c9ff9e0355',1,'Projekt::Database_PracownicyDataSetTableAdapters::TableAdapterManager']]],
  ['updateorderoption',['UpdateOrderOption',['../class_projekt_1_1_database___pracownicy_data_set_table_adapters_1_1_table_adapter_manager.html#aecba9a3624f9186b7113ad03af862e0d',1,'Projekt::Database_PracownicyDataSetTableAdapters::TableAdapterManager']]],
  ['updateupdatedrows',['UpdateUpdatedRows',['../class_projekt_1_1_database___pracownicy_data_set_table_adapters_1_1_table_adapter_manager.html#a6794d649a7d1c44de2cbfd1ab662d5c7',1,'Projekt::Database_PracownicyDataSetTableAdapters::TableAdapterManager']]],
  ['user_5fid',['user_id',['../class_projekt_1_1_data_base_connection.html#ac223861248624b64f9582d659bbd3a2d',1,'Projekt::DataBaseConnection']]]
];
