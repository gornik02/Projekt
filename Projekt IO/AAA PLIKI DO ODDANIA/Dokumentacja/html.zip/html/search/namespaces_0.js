var searchData=
[
  ['database_5fpracownicydatasettableadapters',['Database_PracownicyDataSetTableAdapters',['../namespace_projekt_1_1_database___pracownicy_data_set_table_adapters.html',1,'Projekt']]],
  ['projekt',['Projekt',['../namespace_projekt.html',1,'']]],
  ['properties',['Properties',['../namespace_projekt_1_1_properties.html',1,'Projekt']]]
];
