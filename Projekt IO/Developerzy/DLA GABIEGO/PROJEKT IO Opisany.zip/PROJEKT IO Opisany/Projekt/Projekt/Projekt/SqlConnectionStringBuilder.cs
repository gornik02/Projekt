﻿namespace Projekt
{
    internal class SqlConnectionStringBuilder
    {
    }
}