﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt
{
    public partial class Form3 : Form
    {
        //DataBaseConnection DB = new DataBaseConnection();
        Main_Form main_form;
        public Form3(Main_Form form)
        {

            InitializeComponent();
            main_form = form;
        }

        private void Clean()
        {
            this.Imie.Text = "";
            this.Naz.Text = "";
            this.Pesel.Text = "";
            this.Stanow.Text = "";
            this.pensja_netto.Text = "";
        }

        private void Enter_Click_1(object sender, EventArgs e)      //Dodawanie Pracownika
        {
            if ((Imie.Text !="" && Naz.Text != "") && Pesel.Text != "" && ((PlecM.Checked != false &&PlecK.Checked == false) || (PlecM.Checked == false && PlecK.Checked != false)) && Stanow.Text != "" && ((StudentTak.Checked!=false && StudentNie.Checked==false)||(StudentTak.Checked==false&&StudentNie.Checked!=false))&& RodzajZat.SelectedItem.ToString()!="" && pensja_netto.Text!="" )
            {
                string czystu ,plec;
                if (StudentTak.Checked == true) czystu = "Tak";
                else czystu="Nie";
                if (PlecM.Checked == true) plec = "Mężczyzna";
                else plec = "Kobieta";
                main_form.DB.Add_Person(main_form.people.Count+1, Imie.Text, Naz.Text, Pesel.Text,plec, Stanow.Text, czystu, RodzajZat.SelectedItem.ToString(), pensja_netto.Text);
                main_form.Refresh_Data();
                Clean();
                Enter.Text = "";
                Enter.Text = "Dodaj kolejną osobę";
                MessageBox.Show("Pomyślnie dodano!");
            }
            else
                MessageBox.Show("Wypełnij wszystkie pola!");
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
