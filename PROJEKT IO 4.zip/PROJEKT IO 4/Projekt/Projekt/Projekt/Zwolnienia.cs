﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt
{
    public class Zwolnienia
    {
        public int id { get; set; }

        public string pesel { get; set; }
       
        public string nip { get; set; }

        public string typZwolnienia { get; set; }

        public string ZwolnienieOd { get; set; }

        public string ZwolnienieDo { get; set; }


    }
}
