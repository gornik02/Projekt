﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace Projekt
{

    public class DataBaseConnection
    {
        //  Set Data to Connecting
        private string _connectionData, server_name, user_id, password, database_name;
        bool connect_condition = false;

        private MySqlConnection connectionstring;

        public string _ConnectionData
        {
            set { _connectionData = value; }
            get { return _connectionData; }
        }

        public DataBaseConnection(string server_name, string user_id, string password, string database_name)
        {
            this.server_name = server_name;
            this.user_id = user_id;
            this.password = password;
            this.database_name = database_name;
            this._ConnectionData = "server=" + server_name + ";user id=" + user_id + ";password=" + password + ";database=" + database_name;
            connectionstring = new MySqlConnection(_connectionData);
            //connectionstring = new MySqlConnection("server=localhost;user id=root;password=;database=Pracownicy");
        }

        //  Connecting
        //  MySqlConnection connectionstring = new MySqlConnection("server=localhost;user id=root;database=pracownicy");

        public void OpenConnection()
        {
            connectionstring.Open();
            connect_condition = true;
        }

        public void CloseConnection()
        {
            connectionstring.Close();
            connect_condition = false;
        }

        public bool Condition
        {
            get { return connect_condition; }
        }

        public DataTable ReadAllValues()
        {
            DataTable DT = new DataTable();
            MySqlDataAdapter DA = new MySqlDataAdapter("select* from Pracownicy", connectionstring);
            DA.Fill(DT);
            return DT;
        }

        public DataTable Write_SQL_Question(string SQL_Question)
        {
            DataTable DT = new DataTable();
            MySqlDataAdapter DA = new MySqlDataAdapter(SQL_Question, connectionstring);
            DA.Fill(DT);
            return DT;
        }

        public void Add_Person(int id,string imie,string nazwisko,int pesel,string plec,string stanowisko)
        {
            //INSERT INTO `Pracownicy` (`Id`, `Imie`, `Nazwisko`, `Numer_PESEL`, `Plec`, `Stanowisko`) VALUES ('11', 'Józek', 'ABC', '12345', 'M', 'ST2');
            string values = String.Format(" ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}')", id, imie, nazwisko, pesel, plec, stanowisko); 
            MySqlDataAdapter DA = new MySqlDataAdapter("INSERT INTO `Pracownicy` (`Id`, `Imie`, `Nazwisko`, `Numer_PESEL`, `Plec`, `Stanowisko`) VALUES" + values, connectionstring);
        }
    }
    static class Program
    {
        /// <summary>
        /// Główny punkt wejścia dla aplikacji.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
