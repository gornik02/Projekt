﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace Projekt
{

    class DataBaseConnection
    {
            //  Set Data to Connecting
        private string _connectionData, server_name, user_id, password, database_name;

        private MySqlConnection connectionstring;

        public string _ConnectionData
        {
            set { _connectionData = value; }
            get { return _connectionData; }
        }

        public DataBaseConnection(string server_name, string user_id, string password, string database_name)
        {
            this.server_name = server_name;
            this.user_id = user_id;
            this.password = password;
            this.database_name = database_name;
            this._ConnectionData = "server=" + server_name + ";user id=" + user_id + ";password=" + password + ";database=" + database_name;
            connectionstring = new MySqlConnection(_connectionData);
        }

        public DataBaseConnection()
        {
            connectionstring = new MySqlConnection("server=localhost;user id=root;password=;database=pracownicy");
        }
        
            //  Connecting
            //  MySqlConnection connectionstring = new MySqlConnection("server=localhost;user id=root;database=pracownicy");
        public void OpenConnection()
        {
            connectionstring.Open();
        }
        public void CloseConnection()
        {
            connectionstring.Close();
        }
        public DataTable ReadAllValues()
        {
            DataTable DT = new DataTable();
            MySqlDataAdapter DA = new MySqlDataAdapter("select* from pracownicy", connectionstring);
            DA.Fill(DT);
            return DT;
        }
    }
    static class Program
    {
        /// <summary>
        /// Główny punkt wejścia dla aplikacji.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
