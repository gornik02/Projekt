﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;
using MySql.Data.MySqlClient;
using System.IO;
namespace Projekt
{
    public partial class Form1 : Form
    {
        private Form2 PeopleData_Form = new Form2();
        private Form3 AddForm = new Form3();
        public DataBaseConnection DB;
        private List<Persons> people;
        public Form1()
        {
            InitializeComponent();
            red_yellow_green.BackColor = Color.FromName("Red");
            try    // to można skrócić do funkcji
            {
                StreamReader SR = new StreamReader("ConnectingData.txt");
                int counter = 0;
                string line = "";
                while ((line = SR.ReadLine()) != null)
                {
                    if (counter == 0)
                        server_name.Text = line;
                    else if (counter == 1)
                        user_id.Text = line;
                    else if (counter == 2)
                        password.Text = line;
                    else if (counter == 3)
                        database_name.Text = line;
                    counter++;
                }
                SR.Close();
            }
            catch (FileNotFoundException File)
            {
                MessageBox.Show("Nie można znaleźć pliku " + File.FileName.ToString());
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                DB = new DataBaseConnection(server_name.Text, user_id.Text, password.Text, database_name.Text);
                DB.OpenConnection();
                red_yellow_green.BackColor = Color.FromName("Green");
                people = GetPeopleList();
                listView1.Items.Clear();
                foreach (var Persons in people)
                {
                    var row = new string[] { Persons.ID.ToString(), Persons.IMIE, Persons.NAZWISKO, Persons.PESEL.ToString(), Persons.PLEC, Persons.STANOWISKO };
                    var lvi = new ListViewItem(row);
                    lvi.Tag = Persons;
                    listView1.Items.Add(lvi);
                }
                DataTable DT = new DataTable();
                DT = DB.ReadAllValues();
                dataGridView1.DataSource = DT;
            }
            catch (Exception)
            {
                MessageBox.Show("Bład połączenia! Sprawdź połączenie z internetem oraz dane logowania do bazy danych...");
            }

        }


        private List<Persons> GetPeopleList()
        {
            var list = new List<Persons>();
            DataTable DT = new DataTable();
            DT = DB.ReadAllValues();
            int row_counter = 0;
            while (DT != null && row_counter < DT.Rows.Count)
            {
                list.Add(new Persons() {ID = Convert.ToInt32(DT.Rows[row_counter]["Id"]),IMIE = DT.Rows[row_counter]["Imie"].ToString(), NAZWISKO = DT.Rows[row_counter]["Nazwisko"].ToString(), PESEL = Convert.ToInt32(DT.Rows[row_counter]["Numer_PESEL"]), PLEC = DT.Rows[row_counter]["Plec"].ToString() , STANOWISKO= DT.Rows[row_counter]["Stanowisko"].ToString() });
                row_counter++;
            }
            return list;
        }

        void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            PeopleData_Form.Hide();
        }

        public class AutoClosingMessageBox
        {
            System.Threading.Timer _timeoutTimer;
            string _caption;
            AutoClosingMessageBox(string text, string caption, int timeout)
            {
                _caption = caption;
                _timeoutTimer = new System.Threading.Timer(OnTimerElapsed,
                    null, timeout, System.Threading.Timeout.Infinite);
                MessageBox.Show(text, caption);
            }
            public static void Show(string text, string caption, int timeout)
            {
                new AutoClosingMessageBox(text, caption, timeout);
            }
            void OnTimerElapsed(object state)
            {
                IntPtr mbWnd = FindWindow(null, _caption);
                if (mbWnd != IntPtr.Zero)
                    SendMessage(mbWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
                _timeoutTimer.Dispose();
            }
            const int WM_CLOSE = 0x0010;
            [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
            static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
            [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
            static extern IntPtr SendMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, IntPtr lParam);
        }

        private void button2_Click(object sender, EventArgs e)      //POŁĄCZ
        {
            if (DB.Condition)
                MessageBox.Show("Już połączono!");
            else
            {
                try
                {
                    System.Timers.Timer timer = new System.Timers.Timer();
                    DataTable DT = new DataTable();
                    red_yellow_green.BackColor = Color.FromName("Yellow");
                    AutoClosingMessageBox.Show("Łączenie z MySQL...", "Czekaj", 500);
                    DB = new DataBaseConnection(server_name.Text, user_id.Text, password.Text, database_name.Text);
                    DB.OpenConnection();
                    if (DB.Condition)
                    {
                        StreamWriter SW = new StreamWriter("ConnectingData.txt");
                        SW.Write(server_name.Text + "\r\n" + user_id.Text + "\r\n" + password.Text + "\r\n" + database_name.Text);
                        SW.Close();
                        red_yellow_green.BackColor = Color.FromName("Green");
                        MessageBox.Show("Połaczono!");
                        DT = DB.ReadAllValues();
                        dataGridView1.DataSource = DT;
                        listView1.Items.Clear();
                        foreach (var Persons in people)
                        {
                            var row = new string[] { Persons.ID.ToString(), Persons.IMIE, Persons.NAZWISKO, Persons.PESEL.ToString(), Persons.PLEC, Persons.STANOWISKO };
                            var lvi = new ListViewItem(row);
                            lvi.Tag = Persons;
                            listView1.Items.Add(lvi);
                        }
                    }
                }
                catch (Exception ex)
                {
                    red_yellow_green.BackColor = Color.FromName("Red");
                    MessageBox.Show("Bład połączenia! Sprawdź dane i spróbuj ponownie...");
                }
            }

        }

        private void button3_Click(object sender, EventArgs e)      //RESET
        {
            StreamWriter SW = new StreamWriter("ConnectingData.txt");
            SW.Close();
            server_name.Text = "";
            user_id.Text = "";
            password.Text = "";
            database_name.Text = "";
            SW.Close();
            DB.CloseConnection();
            dataGridView1.DataSource = null;
            listView1.Items.Clear();
            if (DB.Condition == false)
            {
                red_yellow_green.BackColor = Color.FromName("Red");
            }
        }

        private void button4_Click(object sender, EventArgs e)      //ROZŁĄCZ
        {
            if (DB.Condition == true)
            {
                DB.CloseConnection();
                red_yellow_green.BackColor = Color.FromName("Red");
                dataGridView1.DataSource = null;
                listView1.Items.Clear();
            }
        }


        private void listView1_MouseClick(object sender, MouseEventArgs e)          //Wybieranie pracownika
        {
            try
            {
                if (PeopleData_Form.Visible == false)
                {
                    PeopleData_Form = new Form2();
                    Persons person = new Persons();
                    person = (Persons)listView1.SelectedItems[0].Tag;
                    var selectedItem = person;


                    if (selectedItem != null)
                    {

                        PeopleData_Form.Show();
                        PeopleData_Form.id.Text = selectedItem.ID.ToString();
                        PeopleData_Form.imie.Text = selectedItem.IMIE.ToString();
                        PeopleData_Form.nazwisko.Text = selectedItem.NAZWISKO.ToString();
                        PeopleData_Form.pesel.Text = selectedItem.PESEL.ToString();
                        PeopleData_Form.plec.Text = selectedItem.PLEC.ToString();
                        PeopleData_Form.stanowisko.Text = selectedItem.STANOWISKO.ToString();
                    }
                }


            }
            catch (NullReferenceException)
            {

                throw;
            }
        }

        private void DELETE_Click(object sender, EventArgs e)
        {


        }

        private void UPDATE_Click(object sender, EventArgs e)
        {

        }

        private void CLEAR_Click(object sender, EventArgs e)
        {

        }

        private void ADD_Click(object sender, EventArgs e)
        {
            //AddForm.Show();
        }

    }
}
