﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PdfSharp.Pdf;
using PdfSharp.Drawing;
using System.IO;

namespace Projekt
{
    public partial class Form2 : Form
    {
        Main_Form main_form;
        public Form2(Main_Form form)
        {

            InitializeComponent();
            main_form = form;
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = Directory.GetCurrentDirectory();
            path += "\\Raporty\\wzor.pdf";
            var template = PdfSharp.Pdf.IO.PdfReader.Open(path, PdfSharp.Pdf.IO.PdfDocumentOpenMode.Import);
            PdfDocument raport = new PdfDocument();
            for (int i = 0; i < template.PageCount; i++)
            {
                raport.AddPage(template.Pages[i]);
            }
            string dane = imie.Text+" "+nazwisko.Text;
            XGraphics gfx = XGraphics.FromPdfPage(raport.Pages[0]);
            XFont font = new XFont("Verdana", 14, XFontStyle.BoldItalic);
            XFont font1 = new XFont("Verdana", 12, XFontStyle.Italic);
            string data = System.DateTime.Now.ToString();
            gfx.DrawString(data, font1, XBrushes.Black, new XRect(522, 83, 0, 0), XStringFormats.Default);
            gfx.DrawString(imie.Text, font, XBrushes.Black, new XRect(80, 170, 0, 0), XStringFormats.Default);
            gfx.DrawString(nazwisko.Text, font, XBrushes.Black, new XRect(80, 220, 0, 0), XStringFormats.Default);
            gfx.DrawString("2 500", font, XBrushes.Black, new XRect(80, 270, 0, 0), XStringFormats.Default);
            gfx.DrawString("3 500", font, XBrushes.Black, new XRect(80, 320, 0, 0), XStringFormats.Default);
            gfx.DrawString("-ubezpieczenie zdrowotne        150", font, XBrushes.Black, new XRect(80, 370, 0, 0), XStringFormats.Default);
            string newpath = Directory.GetCurrentDirectory() + "\\Raporty\\" + dane + ".pdf";
            raport.Save(newpath);
            System.Diagnostics.Process.Start(newpath);
            //MessageBox.Show("gotowe");
        }
    }
}
