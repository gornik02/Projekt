﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Configuration;
namespace Projekt
{

    public class DataBaseConnection
    {
        //  Set Data to Connecting
        private string _connectionData, server_name, user_id, password, database_name;
        bool connect_condition = false;

        private MySqlConnection connectionstring;

        public string _ConnectionData
        {
            set { _connectionData = value; }
            get { return _connectionData; }
        }

        public DataBaseConnection(string server_name, string user_id, string password, string database_name)
        {
            this.server_name = server_name;
            this.user_id = user_id;
            this.password = password;
            this.database_name = database_name;
            this._ConnectionData = "server=" + server_name + ";user id=" + user_id + ";password=" + password + ";database=" + database_name;
            connectionstring = new MySqlConnection(_connectionData);
            //connectionstring = new MySqlConnection("server=localhost;user id=root;password=;database=Pracownicy");
        }

        //  Connecting
        //  MySqlConnection connectionstring = new MySqlConnection("server=localhost;user id=root;database=pracownicy");

        public void OpenConnection()
        {
            connectionstring.Open();
            connect_condition = true;
        }

        public void CloseConnection()
        {
            connectionstring.Close();
            connect_condition = false;
        }

        public bool Condition
        {
            get { return connect_condition; }
        }

        public DataTable ReadAllValues()
        {
            DataTable DT = new DataTable();
            MySqlDataAdapter DA = new MySqlDataAdapter("select* from Pracownicy", connectionstring);
            DA.Fill(DT);
            return DT;
        }

        public DataTable ReadAllValues2()
        {
            DataTable DT = new DataTable();
            MySqlDataAdapter DA = new MySqlDataAdapter("select* from Ksiegowi", connectionstring);
            DA.Fill(DT);
            return DT;
        }

        public DataTable Write_SQL_Question(string SQL_Question)
        {
            DataTable DT = new DataTable();
            MySqlDataAdapter DA = new MySqlDataAdapter(SQL_Question, connectionstring);
            DA.Fill(DT);
            return DT;
        }

        public void Add_Person(int id,string imie,string nazwisko,string pesel,string plec,string stanowisko)      //Add Person 2/2
        {
            using (var connection = new MySqlConnection(_connectionData))
            {
                connection.Open();
                var sql = "INSERT INTO Pracownicy(Id,Imie, Nazwisko,Numer_PESEL,Plec,Stanowisko) VALUES(@Id, @Imie, @Nazwisko,@Numer_PESEL,@Plec,@Stanowisko)";
                using (var cmd = new MySqlCommand(sql, connection))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Parameters.AddWithValue("@Imie", imie);
                    cmd.Parameters.AddWithValue("@Nazwisko", nazwisko);
                    cmd.Parameters.AddWithValue("@Numer_PESEL", pesel);
                    cmd.Parameters.AddWithValue("@Plec", plec);
                    cmd.Parameters.AddWithValue("@Stanowisko", stanowisko);
                    cmd.ExecuteNonQuery();
                }
                connection.Close();
            }
        }
        public void Add_Person2(int id,string iden_firmowy, string imie, string nazwisko, string login, string haslo)      //Add Ksiegowa 2/2
        {
            using (var connection = new MySqlConnection(_connectionData))
            {
                connection.Open();
                var sql = "INSERT INTO Ksiegowi(ID, ID_Firmowy, Imie, Nazwisko, Login, Haslo) VALUES(@ID, @ID_Firmowy, @Imie, @Nazwisko, @Login, @Haslo)";
                using (var cmd = new MySqlCommand(sql, connection))
                {
                    cmd.Parameters.AddWithValue("@ID", id);
                    cmd.Parameters.AddWithValue("@ID_Firmowy", iden_firmowy);
                    cmd.Parameters.AddWithValue("@Imie", imie);
                    cmd.Parameters.AddWithValue("@Nazwisko", nazwisko);
                    cmd.Parameters.AddWithValue("@Login", login);
                    cmd.Parameters.AddWithValue("@Haslo", haslo);
                    cmd.ExecuteNonQuery();
                }
                connection.Close();
            }
        }
        public void Delete_Person(List<int> lista_indeksow,int id,string imie, string nazwisko, string pesel, string plec, string stanowisko)      //Delete Person 3/3
        {
            using (var connection = new MySqlConnection(_connectionData))
            {
                connection.Open();
                var sql = "Delete From Pracownicy Where Imie = @Imie AND Nazwisko = @Nazwisko AND Numer_PESEL = @Numer_PESEL AND Plec = @Plec And Stanowisko = @Stanowisko" ;
                using (var cmd = new MySqlCommand(sql, connection))
                {
                    cmd.Parameters.AddWithValue("@Imie", imie);
                    cmd.Parameters.AddWithValue("@Nazwisko", nazwisko);
                    cmd.Parameters.AddWithValue("@Numer_PESEL", pesel);
                    cmd.Parameters.AddWithValue("@Plec", plec);
                    cmd.Parameters.AddWithValue("@Stanowisko", stanowisko);
                    cmd.ExecuteNonQuery();
                }
                connection.Close();
            }
            lista_indeksow.Remove(id);      //Usunięcie akutalnie usuniętego
            //Change_Index_When_Deleted(lista_indeksow);
        }
        public void Change_Index_When_Deleted(List<int> lista_indeksow)      //Ustawianie indeksów po usuwaniu
        {
            using (var connection = new MySqlConnection(_connectionData))
            {
                connection.Open();
                var sql = "UPDATE Pracownicy SET Id = @incid Where Id = @autoid";
                using (var cmd = new MySqlCommand(sql, connection))
                {
                        for (int i = 0; i < lista_indeksow.Count; i++)
                        {
                            cmd.Parameters.AddWithValue("@autoid", lista_indeksow[i]);
                            cmd.Parameters.AddWithValue("@incid", i);
                            cmd.ExecuteNonQuery();
                            cmd.Parameters.RemoveAt(0);
                            cmd.Parameters.RemoveAt(0);
                    }

                    } 
                connection.Close();
            }
        }
    }
    static class Program
    {
        /// <summary>
        /// Główny punkt wejścia dla aplikacji.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Main_Form());
        }
    }
}
