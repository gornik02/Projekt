﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt
{
    public partial class Form3 : Form
    {
        //DataBaseConnection DB = new DataBaseConnection();
        Main_Form main_form;
        public Form3(Main_Form form)
        {

            InitializeComponent();
            main_form = form;
        }

        private void Clean()
        {
            this.Imie.Text = "";
            this.Naz.Text = "";
            this.Pesel.Text = "";
            this.Plec.Text = "";
            this.Stanow.Text = "";
        }

        private void Enter_Click_1(object sender, EventArgs e)      //Dodawanie Pracownika
        {
            if (((Imie.Text !="" && Naz.Text != "") && (Pesel.Text != "" && Plec.Text != "")) && Stanow.Text != "")
            {
                main_form.DB.Add_Person(main_form.people.Count,Imie.Text, Naz.Text, Pesel.Text, Plec.Text, Stanow.Text);
                main_form.Refresh_Data();
                Clean();
                Enter.Text = "";
                Enter.Text = "Dodaj kolejną osobę";
                MessageBox.Show("Pomyślnie dodano!");
            }
            else
                MessageBox.Show("Wypełnij wszystkie pola!");
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
