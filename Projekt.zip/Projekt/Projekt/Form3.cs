﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt
{
    public partial class Form3 : Form
    {
        //DataBaseConnection DB = new DataBaseConnection();
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void Enter_Click(object sender, EventArgs e)
        {
            Persons person = new Persons();
            //Form1.Add_Person(person.ID, this.Imie.Text, this.Naz.Text, Convert.ToUInt16(this.Pesel.Text), this.Plec.Text, this.Stanow.Text);
        }
    }
}
