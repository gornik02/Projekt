﻿namespace Projekt
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pracownicyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.data_From_Pracownicy_Database = new Projekt.Data_From_Pracownicy_Database();
            this.pracownicyTableAdapter = new Projekt.Data_From_Pracownicy_DatabaseTableAdapters.pracownicyTableAdapter();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.data_From_Pracownicy_Database1 = new Projekt.Data_From_Pracownicy_Database();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.red_yellow_green = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.Rozlacz = new System.Windows.Forms.Button();
            this.Reset = new System.Windows.Forms.Button();
            this.Polacz = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.database_name = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.user_id = new System.Windows.Forms.TextBox();
            this.server_name = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.listView1 = new System.Windows.Forms.ListView();
            this.chID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chImie = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chNazwisko = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chPlec = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chStanowisko = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            ((System.ComponentModel.ISupportInitialize)(this.pracownicyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.data_From_Pracownicy_Database)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.data_From_Pracownicy_Database1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // pracownicyBindingSource
            // 
            this.pracownicyBindingSource.DataMember = "pracownicy";
            this.pracownicyBindingSource.DataSource = this.data_From_Pracownicy_Database;
            // 
            // data_From_Pracownicy_Database
            // 
            this.data_From_Pracownicy_Database.DataSetName = "Data_From_Pracownicy_Database";
            this.data_From_Pracownicy_Database.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pracownicyTableAdapter
            // 
            this.pracownicyTableAdapter.ClearBeforeFill = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(774, 0);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dateTimePicker1.Size = new System.Drawing.Size(205, 20);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // data_From_Pracownicy_Database1
            // 
            this.data_From_Pracownicy_Database1.DataSetName = "Data_From_Pracownicy_Database";
            this.data_From_Pracownicy_Database1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(768, 461);
            this.tabControl1.TabIndex = 5;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.red_yellow_green);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.Rozlacz);
            this.tabPage1.Controls.Add(this.Reset);
            this.tabPage1.Controls.Add(this.Polacz);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.database_name);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.password);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.user_id);
            this.tabPage1.Controls.Add(this.server_name);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(760, 432);
            this.tabPage1.TabIndex = 1;
            this.tabPage1.Text = "Połączenie z bazą danych";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // red_yellow_green
            // 
            this.red_yellow_green.BackColor = System.Drawing.Color.Red;
            this.red_yellow_green.Location = new System.Drawing.Point(528, 42);
            this.red_yellow_green.Name = "red_yellow_green";
            this.red_yellow_green.Size = new System.Drawing.Size(25, 25);
            this.red_yellow_green.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(485, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Status";
            // 
            // Rozlacz
            // 
            this.Rozlacz.Location = new System.Drawing.Point(368, 212);
            this.Rozlacz.Name = "Rozlacz";
            this.Rozlacz.Size = new System.Drawing.Size(96, 23);
            this.Rozlacz.TabIndex = 10;
            this.Rozlacz.Text = "Rozłącz";
            this.Rozlacz.UseVisualStyleBackColor = true;
            this.Rozlacz.Click += new System.EventHandler(this.button4_Click);
            // 
            // Reset
            // 
            this.Reset.Location = new System.Drawing.Point(244, 212);
            this.Reset.Name = "Reset";
            this.Reset.Size = new System.Drawing.Size(96, 23);
            this.Reset.TabIndex = 9;
            this.Reset.Text = "Reset";
            this.Reset.UseVisualStyleBackColor = true;
            this.Reset.Click += new System.EventHandler(this.button3_Click);
            // 
            // Polacz
            // 
            this.Polacz.Location = new System.Drawing.Point(129, 212);
            this.Polacz.Name = "Polacz";
            this.Polacz.Size = new System.Drawing.Size(96, 23);
            this.Polacz.TabIndex = 8;
            this.Polacz.Text = "Połącz";
            this.Polacz.UseVisualStyleBackColor = true;
            this.Polacz.Click += new System.EventHandler(this.button2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(103, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Nazwa bazy danych";
            // 
            // database_name
            // 
            this.database_name.Location = new System.Drawing.Point(212, 158);
            this.database_name.Name = "database_name";
            this.database_name.Size = new System.Drawing.Size(215, 20);
            this.database_name.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(170, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Hasło";
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(212, 123);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(215, 20);
            this.password.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(104, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nazwa użytkownika";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(126, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nazwa serwera";
            // 
            // user_id
            // 
            this.user_id.Location = new System.Drawing.Point(212, 86);
            this.user_id.Name = "user_id";
            this.user_id.Size = new System.Drawing.Size(215, 20);
            this.user_id.TabIndex = 1;
            // 
            // server_name
            // 
            this.server_name.Location = new System.Drawing.Point(212, 47);
            this.server_name.Name = "server_name";
            this.server_name.Size = new System.Drawing.Size(215, 20);
            this.server_name.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(760, 432);
            this.tabPage2.TabIndex = 2;
            this.tabPage2.Text = "Widok bazodanowy";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(22, 6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(717, 287);
            this.dataGridView1.TabIndex = 2;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.listView1);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(760, 432);
            this.tabPage3.TabIndex = 3;
            this.tabPage3.Text = "Dane";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chID,
            this.chImie,
            this.chNazwisko,
            this.chPlec,
            this.chStanowisko});
            this.listView1.Location = new System.Drawing.Point(6, 6);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(730, 370);
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // chID
            // 
            this.chID.Text = "ID";
            // 
            // chImie
            // 
            this.chImie.Text = "Imię";
            this.chImie.Width = 120;
            // 
            // chNazwisko
            // 
            this.chNazwisko.Text = "Nazwisko";
            this.chNazwisko.Width = 120;
            // 
            // chPlec
            // 
            this.chPlec.Text = "Płeć";
            this.chPlec.Width = 213;
            // 
            // chStanowisko
            // 
            this.chStanowisko.Text = "Stanowisko";
            this.chStanowisko.Width = 250;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(987, 597);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.dateTimePicker1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pracownicyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.data_From_Pracownicy_Database)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.data_From_Pracownicy_Database1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Data_From_Pracownicy_Database data_From_Pracownicy_Database;
        private System.Windows.Forms.BindingSource pracownicyBindingSource;
        private Data_From_Pracownicy_DatabaseTableAdapters.pracownicyTableAdapter pracownicyTableAdapter;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private Data_From_Pracownicy_Database data_From_Pracownicy_Database1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox user_id;
        private System.Windows.Forms.TextBox server_name;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Polacz;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox database_name;
        private System.Windows.Forms.Button Reset;
        private System.Windows.Forms.Button Rozlacz;
        private System.Windows.Forms.Panel red_yellow_green;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader chID;
        private System.Windows.Forms.ColumnHeader chImie;
        private System.Windows.Forms.ColumnHeader chNazwisko;
        private System.Windows.Forms.ColumnHeader chPlec;
        private System.Windows.Forms.ColumnHeader chStanowisko;
    }
}

