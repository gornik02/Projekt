﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using Projekt;

namespace UnitTest
{
    [TestClass]
    public class UnitTest_Wynagrodzenia
    {
        //Tworzy osobe ktora mozna wykorzystac w testach
        public Persons TestowanaOsoba(string IMIE, string PESEL, string PLEC, string STANOWISKO,
                                        string CZY_STUDENT, string RODZAJ_ZATRUDNIENIA, string PENSJA_BRUTTO) {

            Persons p1 = new Persons();
            p1.IMIE = IMIE;
            p1.PESEL = PESEL;
            p1.PLEC = PLEC;
            p1.STANOWISKO = STANOWISKO;
            p1.CZY_STUDENT = CZY_STUDENT;
            p1.RODZAJ_ZATRUDNIENIA = RODZAJ_ZATRUDNIENIA;
            p1.PENSJA_BRUTTO = PENSJA_BRUTTO;            
            return p1;
        }
       

        [TestMethod]
        public void PensjaBruttoTest()
        {
            Persons p1 = TestowanaOsoba("", "", "", "", "", "", "3000");
            List<Zwolnienia> z = new List<Zwolnienia>();  
            Wynagrodzenia w = new Wynagrodzenia(p1, 31, z, 2);

            float oczekiwanaPensjaBrutto = (float)Math.Round((float)Convert.ToDecimal(p1.PENSJA_BRUTTO), 2);


            Assert.AreEqual(oczekiwanaPensjaBrutto, w.PENSJA_BRUTTO);
        }

        [TestMethod]
        //Testuje dla Set2, czyli kiedy pracownik nie ma zwolnien w miesiacu, przypadek umowy o prace, nie student
        public void PensjaNettoTest()
        {
            float G, H, I, J, J1, K, K1, L1, L, M, M1, N, O, O1, P, P1, Q, R, S, T, V;
            int U, W;
            Persons p1 = TestowanaOsoba("Adam", "87111407327", "M", "Informatyk", "NIE", "Umowa o prace", "3000");
            
            int ILOSC_DNI_MIESIAC = 31;            
            int miesiac = 1;
            Wynagrodzenia w = new Wynagrodzenia(p1, ILOSC_DNI_MIESIAC, miesiac);
            int ILOSC_DNI_PRZEPRACOWANE = ILOSC_DNI_MIESIAC;
            float WYNAGRODZENIE_ZASADNICZE = (float)Math.Round((float)Convert.ToDecimal(p1.PENSJA_BRUTTO), 2);
            G = (float)Math.Round(WYNAGRODZENIE_ZASADNICZE / ILOSC_DNI_MIESIAC, 2);
            H = (float)Math.Round(WYNAGRODZENIE_ZASADNICZE, 2);
            J = (float)Math.Round(H * (float)0.0976, 2);
            K = (float)Math.Round(H * (float)0.015, 2);
            L = (float)Math.Round(H * (float)0.0245, 2);
            M = (float)Math.Round(J + K + L, 2);
            N = (float)Math.Round(M, 2);
            O = (float)Math.Round(H - M, 2);
            P = (float)Math.Round(O * (float)0.09, 2);
            Q = (float)Math.Round(P, 2);
            R = (float)Math.Round(O * (float)0.0775, 2);

            S = (float)111.25;  //Stała kwota
            T = (float)46.33;   //Stała kwota
            U = (int)(H - M - S);
            V = (float)Math.Round(U * (float)0.18 - T, 2);
            W = (int)(V - R);
            float PENSJA_NETTO = (float)Math.Round(H - N - Q - W, 2);


           
            float oczekiwanaPensjaNetto = 2157.72f;

            Assert.AreEqual(PENSJA_NETTO, oczekiwanaPensjaNetto);
        }

        [TestMethod]
        //Testuje dla Set2, czyli kiedy pracownik nie ma zwolnien w miesiacu, przypadek umowy o prace, nie student
        public void PENSJA_BRUTTO_BRUTTOTest()
        {
            float G, H, I, J, J1, K, K1, L1, L, M, M1, N, O, O1, P, P1, Q, R, S, T, V;
            int U, W;
            Persons p1 = TestowanaOsoba("Adam", "87111407327", "M", "Informatyk", "NIE", "Umowa o prace", "3000");
            
            int ILOSC_DNI_MIESIAC = 31;
            int miesiac = 1;
            Wynagrodzenia w = new Wynagrodzenia(p1, ILOSC_DNI_MIESIAC, miesiac);
            int ILOSC_DNI_PRZEPRACOWANE = ILOSC_DNI_MIESIAC;
            float WYNAGRODZENIE_ZASADNICZE = (float)Math.Round((float)Convert.ToDecimal(p1.PENSJA_BRUTTO), 2);
            float PENSJA_BRUTTO = WYNAGRODZENIE_ZASADNICZE;
            G = (float)Math.Round(WYNAGRODZENIE_ZASADNICZE / ILOSC_DNI_MIESIAC, 2);
            H = (float)Math.Round(WYNAGRODZENIE_ZASADNICZE, 2);
            J = (float)Math.Round(H * (float)0.0976, 2);
            K = (float)Math.Round(H * (float)0.015, 2);
            L = (float)Math.Round(H * (float)0.0245, 2);
            M = (float)Math.Round(J + K + L, 2);
            N = (float)Math.Round(M, 2);
            O = (float)Math.Round(H - M, 2);
            P = (float)Math.Round(O * (float)0.09, 2);
            Q = (float)Math.Round(P, 2);
            R = (float)Math.Round(O * (float)0.0775, 2);

            S = (float)111.25;  //Stała kwota
            T = (float)46.33;   //Stała kwota
            U = (int)(H - M - S);
            V = (float)Math.Round(U * (float)0.18 - T, 2);
            W = (int)(V - R);
            float PENSJA_NETTO = (float)Math.Round(H - N - Q - W, 2);
            float emerytalna, rentowa, wypadkowa, fundusz_pracy, sumaPracodawca, PENSJA_BRUTTO_BRUTTO;
            emerytalna = (float)Math.Round(H * (float)0.0976, 2);
            rentowa = (float)Math.Round(H * (float)0.085, 2);
            wypadkowa = (float)Math.Round(H * (float)0.017, 2);
            fundusz_pracy = (float)Math.Round(H * (float)0.0245, 2);
            sumaPracodawca = (float)Math.Round(emerytalna + rentowa + wypadkowa + fundusz_pracy, 2);
            PENSJA_BRUTTO_BRUTTO = (float)Math.Round(PENSJA_BRUTTO + sumaPracodawca, 2);


            float oczekiwanaPensjaBruttoBrutto = 3672.3f;

            Assert.AreEqual(PENSJA_BRUTTO_BRUTTO, oczekiwanaPensjaBruttoBrutto);
        }

        //[TestMethod]
        //Do poprawienia
        //Testuje dla Set2, czyli kiedy pracownik nie ma zwolnien w miesiacu, przypadek umowy o prace, nie student
        //public void SkładkiSumaTest()
        //{
        //    float G, H, I, J, J1, K, K1, L1, L, M, M1, N, O, O1, P, P1, Q, R, S, T, V;
        //    int U, W;
        //    Persons p1 = TestowanaOsoba("Adam", "87111407327", "M", "Informatyk", "NIE", "Umowa o prace", "3000");

        //    int ILOSC_DNI_MIESIAC = 31;
        //    int miesiac = 1;
        //    Wynagrodzenia w = new Wynagrodzenia(p1, ILOSC_DNI_MIESIAC, miesiac);
        //    int ILOSC_DNI_PRZEPRACOWANE = ILOSC_DNI_MIESIAC;
        //    float WYNAGRODZENIE_ZASADNICZE = (float)Math.Round((float)Convert.ToDecimal(p1.PENSJA_BRUTTO), 2);
        //    float PENSJA_BRUTTO = WYNAGRODZENIE_ZASADNICZE;
        //    G = (float)Math.Round(WYNAGRODZENIE_ZASADNICZE / ILOSC_DNI_MIESIAC, 2);
        //    H = (float)Math.Round(WYNAGRODZENIE_ZASADNICZE, 2);
        //    J = (float)Math.Round(H * (float)0.0976, 2);
        //    K = (float)Math.Round(H * (float)0.015, 2);
        //    L = (float)Math.Round(H * (float)0.0245, 2);
        //    M = (float)Math.Round(J + K + L, 2);
        //    N = (float)Math.Round(M, 2);
        //    O = (float)Math.Round(H - M, 2);
        //    P = (float)Math.Round(O * (float)0.09, 2);
        //    Q = (float)Math.Round(P, 2);
        //    R = (float)Math.Round(O * (float)0.0775, 2);

        //    S = (float)111.25;  //Stała kwota
        //    T = (float)46.33;   //Stała kwota
        //    U = (int)(H - M - S);
        //    V = (float)Math.Round(U * (float)0.18 - T, 2);
        //    W = (int)(V - R);
        //    float PENSJA_NETTO = (float)Math.Round(H - N - Q - W, 2);
        //    float emerytalna, rentowa, wypadkowa, fundusz_pracy, sumaPracodawca, PENSJA_BRUTTO_BRUTTO;
        //    emerytalna = (float)Math.Round(H * (float)0.0976, 2);
        //    rentowa = (float)Math.Round(H * (float)0.085, 2);
        //    wypadkowa = (float)Math.Round(H * (float)0.017, 2);
        //    fundusz_pracy = (float)Math.Round(H * (float)0.0245, 2);
        //    sumaPracodawca = (float)Math.Round(emerytalna + rentowa + wypadkowa + fundusz_pracy, 2);
        //    PENSJA_BRUTTO_BRUTTO = (float)Math.Round(PENSJA_BRUTTO + sumaPracodawca, 2);

        //    float SkładkiSuma = J + K + L + P;

        //    float oczekiwanaSkładkiSuma = 644.28f;

        //    Assert.AreEqual(SkładkiSuma, oczekiwanaSkładkiSuma);
        //}

        [TestMethod]
        //Testuje dla Set2, czyli kiedy pracownik nie ma zwolnien w miesiacu, przypadek umowy o prace, nie student
        public void SKŁADKA_EMERYTALNATest()
        {
            float G, H, I, J, J1, K, K1, L1, L, M, M1, N, O, O1, P, P1, Q, R, S, T, V;
            int U, W;
            Persons p1 = TestowanaOsoba("Adam", "87111407327", "M", "Informatyk", "NIE", "Umowa o prace", "3000");

            int ILOSC_DNI_MIESIAC = 31;
            int miesiac = 1;
            Wynagrodzenia w = new Wynagrodzenia(p1, ILOSC_DNI_MIESIAC, miesiac);
            int ILOSC_DNI_PRZEPRACOWANE = ILOSC_DNI_MIESIAC;
            float WYNAGRODZENIE_ZASADNICZE = (float)Math.Round((float)Convert.ToDecimal(p1.PENSJA_BRUTTO), 2);
            float PENSJA_BRUTTO = WYNAGRODZENIE_ZASADNICZE;
            G = (float)Math.Round(WYNAGRODZENIE_ZASADNICZE / ILOSC_DNI_MIESIAC, 2);
            H = (float)Math.Round(WYNAGRODZENIE_ZASADNICZE, 2);
            J = (float)Math.Round(H * (float)0.0976, 2);
            K = (float)Math.Round(H * (float)0.015, 2);
            L = (float)Math.Round(H * (float)0.0245, 2);
            M = (float)Math.Round(J + K + L, 2);
            N = (float)Math.Round(M, 2);
            O = (float)Math.Round(H - M, 2);
            P = (float)Math.Round(O * (float)0.09, 2);
            Q = (float)Math.Round(P, 2);
            R = (float)Math.Round(O * (float)0.0775, 2);

            S = (float)111.25;  //Stała kwota
            T = (float)46.33;   //Stała kwota
            U = (int)(H - M - S);
            V = (float)Math.Round(U * (float)0.18 - T, 2);
            W = (int)(V - R);
            float PENSJA_NETTO = (float)Math.Round(H - N - Q - W, 2);
            float emerytalna, rentowa, wypadkowa, fundusz_pracy, sumaPracodawca, PENSJA_BRUTTO_BRUTTO;
            emerytalna = (float)Math.Round(H * (float)0.0976, 2);
            rentowa = (float)Math.Round(H * (float)0.085, 2);
            wypadkowa = (float)Math.Round(H * (float)0.017, 2);
            fundusz_pracy = (float)Math.Round(H * (float)0.0245, 2);
            sumaPracodawca = (float)Math.Round(emerytalna + rentowa + wypadkowa + fundusz_pracy, 2);
            PENSJA_BRUTTO_BRUTTO = (float)Math.Round(PENSJA_BRUTTO + sumaPracodawca, 2);

            float SKŁADKA_EMERYTALNA = (float)Math.Round(H * (float)0.0976, 2);

            float oczekiwanaSkładkaEmerytalna = 292.8f;

            Assert.AreEqual(SKŁADKA_EMERYTALNA, oczekiwanaSkładkaEmerytalna);
        }

        [TestMethod]
        //Testuje dla Set2, czyli kiedy pracownik nie ma zwolnien w miesiacu, przypadek umowy o prace, nie student
        public void SKŁADKA_RENTOWATest()
        {
            float G, H, I, J, J1, K, K1, L1, L, M, M1, N, O, O1, P, P1, Q, R, S, T, V;
            int U, W;
            Persons p1 = TestowanaOsoba("Adam", "87111407327", "M", "Informatyk", "NIE", "Umowa o prace", "3000");

            int ILOSC_DNI_MIESIAC = 31;
            int miesiac = 1;
            Wynagrodzenia w = new Wynagrodzenia(p1, ILOSC_DNI_MIESIAC, miesiac);
            int ILOSC_DNI_PRZEPRACOWANE = ILOSC_DNI_MIESIAC;
            float WYNAGRODZENIE_ZASADNICZE = (float)Math.Round((float)Convert.ToDecimal(p1.PENSJA_BRUTTO), 2);
            float PENSJA_BRUTTO = WYNAGRODZENIE_ZASADNICZE;
            G = (float)Math.Round(WYNAGRODZENIE_ZASADNICZE / ILOSC_DNI_MIESIAC, 2);
            H = (float)Math.Round(WYNAGRODZENIE_ZASADNICZE, 2);
            J = (float)Math.Round(H * (float)0.0976, 2);
            K = (float)Math.Round(H * (float)0.015, 2);
            L = (float)Math.Round(H * (float)0.0245, 2);
            M = (float)Math.Round(J + K + L, 2);
            N = (float)Math.Round(M, 2);
            O = (float)Math.Round(H - M, 2);
            P = (float)Math.Round(O * (float)0.09, 2);
            Q = (float)Math.Round(P, 2);
            R = (float)Math.Round(O * (float)0.0775, 2);

            S = (float)111.25;  //Stała kwota
            T = (float)46.33;   //Stała kwota
            U = (int)(H - M - S);
            V = (float)Math.Round(U * (float)0.18 - T, 2);
            W = (int)(V - R);
            float PENSJA_NETTO = (float)Math.Round(H - N - Q - W, 2);
            float emerytalna, rentowa, wypadkowa, fundusz_pracy, sumaPracodawca, PENSJA_BRUTTO_BRUTTO;
            emerytalna = (float)Math.Round(H * (float)0.0976, 2);
            rentowa = (float)Math.Round(H * (float)0.085, 2);
            wypadkowa = (float)Math.Round(H * (float)0.017, 2);
            fundusz_pracy = (float)Math.Round(H * (float)0.0245, 2);
            sumaPracodawca = (float)Math.Round(emerytalna + rentowa + wypadkowa + fundusz_pracy, 2);
            PENSJA_BRUTTO_BRUTTO = (float)Math.Round(PENSJA_BRUTTO + sumaPracodawca, 2);

            float SKŁADKA_RENTOWA = (float)Math.Round(H * (float)0.085, 2);

            float oczekiwanaSkładkaRentowa = 255f;

            Assert.AreEqual(SKŁADKA_RENTOWA, oczekiwanaSkładkaRentowa);
        }

        [TestMethod]
        //Testuje dla Set2, czyli kiedy pracownik nie ma zwolnien w miesiacu, przypadek umowy o prace, nie student
        public void SKŁADKA_CHOROBOWATest()
        {
            float G, H, I, J, J1, K, K1, L1, L, M, M1, N, O, O1, P, P1, Q, R, S, T, V;
            int U, W;
            Persons p1 = TestowanaOsoba("Adam", "87111407327", "M", "Informatyk", "NIE", "Umowa o prace", "3000");

            int ILOSC_DNI_MIESIAC = 31;
            int miesiac = 1;
            Wynagrodzenia w = new Wynagrodzenia(p1, ILOSC_DNI_MIESIAC, miesiac);
            int ILOSC_DNI_PRZEPRACOWANE = ILOSC_DNI_MIESIAC;
            float WYNAGRODZENIE_ZASADNICZE = (float)Math.Round((float)Convert.ToDecimal(p1.PENSJA_BRUTTO), 2);
            float PENSJA_BRUTTO = WYNAGRODZENIE_ZASADNICZE;
            G = (float)Math.Round(WYNAGRODZENIE_ZASADNICZE / ILOSC_DNI_MIESIAC, 2);
            H = (float)Math.Round(WYNAGRODZENIE_ZASADNICZE, 2);
            J = (float)Math.Round(H * (float)0.0976, 2);
            K = (float)Math.Round(H * (float)0.015, 2);
            L = (float)Math.Round(H * (float)0.0245, 2);
            M = (float)Math.Round(J + K + L, 2);
            N = (float)Math.Round(M, 2);
            O = (float)Math.Round(H - M, 2);
            P = (float)Math.Round(O * (float)0.09, 2);
            Q = (float)Math.Round(P, 2);
            R = (float)Math.Round(O * (float)0.0775, 2);

            S = (float)111.25;  //Stała kwota
            T = (float)46.33;   //Stała kwota
            U = (int)(H - M - S);
            V = (float)Math.Round(U * (float)0.18 - T, 2);
            W = (int)(V - R);
            float PENSJA_NETTO = (float)Math.Round(H - N - Q - W, 2);
            float emerytalna, rentowa, wypadkowa, fundusz_pracy, sumaPracodawca, PENSJA_BRUTTO_BRUTTO;
            emerytalna = (float)Math.Round(H * (float)0.0976, 2);
            rentowa = (float)Math.Round(H * (float)0.085, 2);
            wypadkowa = (float)Math.Round(H * (float)0.017, 2);
            fundusz_pracy = (float)Math.Round(H * (float)0.0245, 2);
            sumaPracodawca = (float)Math.Round(emerytalna + rentowa + wypadkowa + fundusz_pracy, 2);
            PENSJA_BRUTTO_BRUTTO = (float)Math.Round(PENSJA_BRUTTO + sumaPracodawca, 2);

            float SKŁADKA_CHOROBOWA = L;

            float oczekiwanaSkładkaChorobowa = 73.5f;

            Assert.AreEqual(SKŁADKA_CHOROBOWA, oczekiwanaSkładkaChorobowa);
        }

        [TestMethod]
        //Testuje dla Set2, czyli kiedy pracownik nie ma zwolnien w miesiacu, przypadek umowy o prace, nie student
        public void SKŁADKA_ZDROWOTNATest()
        {
            float G, H, I, J, J1, K, K1, L1, L, M, M1, N, O, O1, P, P1, Q, R, S, T, V;
            int U, W;
            Persons p1 = TestowanaOsoba("Adam", "87111407327", "M", "Informatyk", "NIE", "Umowa o prace", "3000");

            int ILOSC_DNI_MIESIAC = 31;
            int miesiac = 1;
            Wynagrodzenia w = new Wynagrodzenia(p1, ILOSC_DNI_MIESIAC, miesiac);
            int ILOSC_DNI_PRZEPRACOWANE = ILOSC_DNI_MIESIAC;
            float WYNAGRODZENIE_ZASADNICZE = (float)Math.Round((float)Convert.ToDecimal(p1.PENSJA_BRUTTO), 2);
            float PENSJA_BRUTTO = WYNAGRODZENIE_ZASADNICZE;
            G = (float)Math.Round(WYNAGRODZENIE_ZASADNICZE / ILOSC_DNI_MIESIAC, 2);
            H = (float)Math.Round(WYNAGRODZENIE_ZASADNICZE, 2);
            J = (float)Math.Round(H * (float)0.0976, 2);
            K = (float)Math.Round(H * (float)0.015, 2);
            L = (float)Math.Round(H * (float)0.0245, 2);
            M = (float)Math.Round(J + K + L, 2);
            N = (float)Math.Round(M, 2);
            O = (float)Math.Round(H - M, 2);
            P = (float)Math.Round(O * (float)0.09, 2);
            Q = (float)Math.Round(P, 2);
            R = (float)Math.Round(O * (float)0.0775, 2);

            S = (float)111.25;  //Stała kwota
            T = (float)46.33;   //Stała kwota
            U = (int)(H - M - S);
            V = (float)Math.Round(U * (float)0.18 - T, 2);
            W = (int)(V - R);
            float PENSJA_NETTO = (float)Math.Round(H - N - Q - W, 2);
            float emerytalna, rentowa, wypadkowa, fundusz_pracy, sumaPracodawca, PENSJA_BRUTTO_BRUTTO;
            emerytalna = (float)Math.Round(H * (float)0.0976, 2);
            rentowa = (float)Math.Round(H * (float)0.085, 2);
            wypadkowa = (float)Math.Round(H * (float)0.017, 2);
            fundusz_pracy = (float)Math.Round(H * (float)0.0245, 2);
            sumaPracodawca = (float)Math.Round(emerytalna + rentowa + wypadkowa + fundusz_pracy, 2);
            PENSJA_BRUTTO_BRUTTO = (float)Math.Round(PENSJA_BRUTTO + sumaPracodawca, 2);

            float SKŁADKA_ZDROWOTNA = P;

            float oczekiwanaSkładkaZdrowotna = 232.98f;

            Assert.AreEqual(SKŁADKA_ZDROWOTNA, oczekiwanaSkładkaZdrowotna);
        }


    }
}
